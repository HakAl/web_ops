// Original procedural illustrations: every feather, fish, and bubble is drawn locally.
const TAU = Math.PI * 2;
const wrap = (n, max) => ((n % max) + max) % max;
const bounce = (position, span) => {const p=wrap(position,span*2);return p<span?p:span*2-p;};
const noise = n => { const v = Math.sin(n * 127.1 + 311.7) * 43758.5453; return v - Math.floor(v); };
function ellipse(ctx, x, y, rx, ry, color) {
  ctx.fillStyle = color; ctx.beginPath(); ctx.ellipse(x, y, rx, ry, 0, 0, TAU); ctx.fill();
}
function wing(ctx, side, flap, back = false) {
  ctx.save(); ctx.translate(side * 29, -5); ctx.scale(side, .45 + flap * .55);
  const shade = ctx.createLinearGradient(0, -65, 60, 8);
  shade.addColorStop(0, '#fffdf0'); shade.addColorStop(.5, back ? '#b0bdce' : '#eef1f4'); shade.addColorStop(1, '#798697');
  ctx.fillStyle = shade; ctx.strokeStyle = '#596273'; ctx.lineWidth = 1.1;
  ctx.beginPath(); ctx.moveTo(0, 10); ctx.bezierCurveTo(12, -31, 30, -72, 68, -72);
  ctx.bezierCurveTo(63, -55, 52, -40, 41, -26); ctx.bezierCurveTo(31, -9, 20, 5, 0, 10); ctx.fill(); ctx.stroke();
  for (let j = 0; j < 8; j++) {
    ctx.beginPath(); ctx.moveTo(5 + j * 4, 6 - j * 4);
    ctx.quadraticCurveTo(22 + j * 4, -24 - j * 4, 31 + j * 5, -39 - j * 4);
    ctx.strokeStyle = j % 2 ? '#ffffffa0' : '#5f6e8555'; ctx.stroke();
  }
  ctx.restore();
}
function toast(ctx, x, y, scale, angle, time) {
  ctx.save(); ctx.translate(x,y); ctx.rotate(angle); ctx.scale(scale,scale);
  ctx.fillStyle='#9d4d20'; ctx.strokeStyle='#55270f'; ctx.lineWidth=2;
  ctx.beginPath(); ctx.moveTo(-16,19); ctx.lineTo(-18,-7); ctx.bezierCurveTo(-29,-28,28,-32,20,-7); ctx.lineTo(19,19); ctx.closePath(); ctx.fill(); ctx.stroke();
  const bread=ctx.createLinearGradient(0,-20,0,18);bread.addColorStop(0,'#fff0b1');bread.addColorStop(.55,'#d9a354');bread.addColorStop(1,'#e7ba72');ctx.fillStyle=bread;
  ctx.beginPath();ctx.moveTo(-11,14);ctx.lineTo(-12,-8);ctx.bezierCurveTo(-21,-23,22,-25,14,-8);ctx.lineTo(14,14);ctx.closePath();ctx.fill();
  for(let j=0;j<22;j++)ellipse(ctx,noise(j+7)*22-10,noise(j+91)*28-16,.7,.6,'#b67b3a80');
  ctx.fillStyle='#ffe397';ctx.fillRect(-4,-4,11,8);ctx.fillStyle='#fff5bc';ctx.fillRect(-4,-4,11,2);ctx.restore();
}
function toaster(ctx,x,y,scale,phase,t){
  ctx.save();ctx.translate(x,y);ctx.rotate(-.16+Math.sin(t*.7+phase)*.035);ctx.scale(scale,scale);
  const flap=(Math.sin(t*7+phase)+1)/2;
  wing(ctx,1,flap,true);
  // A warm slice peeking out of the rear slot.
  ctx.fillStyle='#a8652c';ctx.strokeStyle='#573d24';ctx.lineWidth=1;
  ctx.beginPath();ctx.moveTo(-15,-27);ctx.lineTo(-16,-40);ctx.bezierCurveTo(-22,-56,18,-55,15,-40);ctx.lineTo(17,-24);ctx.fill();ctx.stroke();
  ctx.fillStyle='#efd197';ctx.beginPath();ctx.moveTo(-11,-30);ctx.lineTo(-11,-40);ctx.bezierCurveTo(-14,-49,12,-49,11,-39);ctx.lineTo(12,-29);ctx.fill();
  // Chrome side, rounded front, and beveled top.
  let metal=ctx.createLinearGradient(-35,-27,32,24);metal.addColorStop(0,'#616d80');metal.addColorStop(.18,'#f2f6fa');metal.addColorStop(.34,'#9cabbc');metal.addColorStop(.51,'#dce5ea');metal.addColorStop(.57,'#788b9f');metal.addColorStop(.83,'#c4cdd4');metal.addColorStop(1,'#3f5064');
  ctx.fillStyle=metal;ctx.strokeStyle='#384457';ctx.lineWidth=1.5;ctx.beginPath();ctx.roundRect(-34,-27,65,51,10);ctx.fill();ctx.stroke();
  ctx.fillStyle='#586879';ctx.beginPath();ctx.moveTo(24,-22);ctx.lineTo(43,-31);ctx.lineTo(43,13);ctx.quadraticCurveTo(40,18,29,23);ctx.lineTo(29,-15);ctx.closePath();ctx.fill();
  const top=ctx.createLinearGradient(0,-37,0,-20);top.addColorStop(0,'#f0f6fa');top.addColorStop(1,'#8a9bac');ctx.fillStyle=top;ctx.beginPath();ctx.moveTo(-30,-27);ctx.lineTo(-15,-37);ctx.lineTo(36,-37);ctx.quadraticCurveTo(44,-36,43,-30);ctx.lineTo(29,-22);ctx.closePath();ctx.fill();
  ctx.lineWidth=4;ctx.strokeStyle='#1f2933';ctx.lineCap='round';ctx.beginPath();ctx.moveTo(-17,-29);ctx.lineTo(23,-30);ctx.stroke();ctx.lineWidth=1;ctx.strokeStyle='#faffff';ctx.beginPath();ctx.moveTo(-26,-19);ctx.lineTo(18,-19);ctx.stroke();
  ctx.fillStyle='#1c2633';ctx.fillRect(34,-17,3,23);ctx.fillStyle='#dce7eb';ctx.fillRect(30,-9+flap*2,12,5);
  ctx.fillStyle='#161b25';ctx.fillRect(-24,24,10,5);ctx.fillRect(18,23,9,5);ellipse(ctx,17,12,4,4,'#3a4552');ellipse(ctx,17,12,2.2,2.2,'#bac4cc');
  ctx.fillStyle='#7b8d9d';ctx.font='5px monospace';ctx.fillText('IDLE',-15,11);
  wing(ctx,-1,flap);ctx.restore();
}
export function drawToasters(ctx,w,h,t,density,interaction){
  const bg=ctx.createRadialGradient(w*.5,h*.4,0,w*.5,h*.5,w*.8);bg.addColorStop(0,'#101225');bg.addColorStop(1,'#020307');ctx.fillStyle=bg;ctx.fillRect(0,0,w,h);
  for(let i=0;i<65;i++){const a=.12+noise(i)*.3;ctx.fillStyle=`rgba(180,191,226,${a})`;ctx.fillRect(noise(i+2)*w,noise(i+124)*h,1,1);}
  const unit=Math.min(w/900,h/530),base=Math.max(.36,unit);
  const count=Math.ceil(12*density);
  const actors=Array.from({length:count},(_,i)=>({i,z:.55+noise(i+1)*.8})).sort((a,b)=>a.z-b.z);
  for(const {i,z}of actors){const s=Math.min(base*z,w/230,h/210);const mx=104*s,my=95*s;const x=mx+bounce(noise(i+8)*Math.max(1,w-2*mx)-t*(26+z*28)*base,Math.max(1,w-2*mx));const y=my+bounce(noise(i+40)*Math.max(1,h-2*my)+t*(12+z*12)*base,Math.max(1,h-2*my));
    if(i%4===3)toast(ctx,x,y,s*.95,-.35+Math.sin(t*.5+i)*.2,t);else toaster(ctx,x,y,s,i*2.3,t);
  }
  if(interaction){const age=t-interaction.time;if(age<4){for(let i=0;i<7;i++){const a=-Math.PI*.85+i*.25;const vx=Math.cos(a)*110*base,vy=Math.sin(a)*130*base;ctx.globalAlpha=Math.max(0,1-age/4);toast(ctx,interaction.x*w+vx*age,interaction.y*h+vy*age+25*base*age*age,base*.65,age*(i%2?1:-1)+i,t);ctx.globalAlpha=1;}}}
}
function bowlPath(ctx,cx,cy,r){
  ctx.beginPath();ctx.moveTo(cx-r*.52,cy-r*.8);ctx.bezierCurveTo(cx-r*.59,cy-r*.63,cx-r*1.12,cy-r*.4,cx-r*.94,cy+r*.27);ctx.bezierCurveTo(cx-r*.83,cy+r*.78,cx-r*.55,cy+r*.87,cx,cy+r*.87);ctx.bezierCurveTo(cx+r*.55,cy+r*.87,cx+r*.83,cy+r*.78,cx+r*.94,cy+r*.27);ctx.bezierCurveTo(cx+r*1.12,cy-r*.4,cx+r*.59,cy-r*.63,cx+r*.52,cy-r*.8);ctx.closePath();
}
function fish(ctx,x,y,s,dir,phase,t,kind,turn=1){
  ctx.save();ctx.translate(x,y);ctx.scale(dir*s*turn,s);const flick=Math.sin(t*8+phase);
  const species=kind%5;
  if(species===1){
    // Angelfish: a tall diamond body, trailing fins, and charcoal bands.
    ctx.fillStyle='#e6d979';ctx.beginPath();ctx.moveTo(23,0);ctx.lineTo(-3,-32);ctx.lineTo(-15,-8);ctx.lineTo(-30,-17);ctx.lineTo(-25,0);ctx.lineTo(-31,15);ctx.lineTo(-15,8);ctx.lineTo(-2,33);ctx.closePath();ctx.fill();
    ellipse(ctx,0,0,19,21,'#ffe7a0');ctx.save();ctx.beginPath();ctx.ellipse(0,0,19,21,0,0,TAU);ctx.clip();ctx.fillStyle='#41474d';ctx.fillRect(-12,-24,5,48);ctx.fillRect(-1,-24,5,48);ctx.fillRect(10,-24,4,48);ctx.restore();
    ctx.strokeStyle='#fff0b2';ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(3,16);ctx.quadraticCurveTo(0,35,-7+flick*2,42);ctx.stroke();ellipse(ctx,13,-4,3,3,'#fff5c6');ellipse(ctx,14,-4,1.5,1.5,'#111923');ctx.restore();return;
  }
  if(species===2){
    // Neon tetra: slim silver body, an electric blue stripe, and a red belly.
    ctx.fillStyle='#6db2c4';ctx.beginPath();ctx.moveTo(-19,0);ctx.lineTo(-31,-9-flick*2);ctx.lineTo(-30,10);ctx.closePath();ctx.fill();ellipse(ctx,0,0,23,8,'#a8cfd0');
    ctx.fillStyle='#24deee';ctx.fillRect(-18,-3,33,4);ctx.fillStyle='#ed444c';ctx.fillRect(-19,2,24,4);ctx.strokeStyle='#94d8df';ctx.beginPath();ctx.moveTo(-4,-7);ctx.lineTo(-1,-16);ctx.lineTo(9,-7);ctx.stroke();ellipse(ctx,16,-2,3,3,'#eff5c6');ellipse(ctx,17,-2,1.5,1.5,'#09141f');ctx.restore();return;
  }
  if(species===3){
    // Pufferfish: a round prickly silhouette and tiny nervous fins.
    ctx.strokeStyle='#e0c480';ctx.lineWidth=2;for(let j=0;j<18;j++){const a=j/18*TAU;ctx.beginPath();ctx.moveTo(Math.cos(a)*21,Math.sin(a)*20);ctx.lineTo(Math.cos(a)*26,Math.sin(a)*25);ctx.stroke();}
    ellipse(ctx,0,0,23,21,'#d6b35d');ellipse(ctx,3,7,17,12,'#eee1a2');for(let j=0;j<16;j++)ellipse(ctx,noise(j+2)*32-17,noise(j+7)*21-15,1.5,1.5,'#716847');
    ctx.fillStyle='#d0a354';ctx.beginPath();ctx.moveTo(-20,0);ctx.lineTo(-33,-7-flick*3);ctx.lineTo(-31,10);ctx.closePath();ctx.fill();ellipse(ctx,15,-5,4,5,'#f6f2cd');ellipse(ctx,17,-5,2,2.5,'#17251e');ellipse(ctx,22,4,3,2,'#7b673a');ctx.restore();return;
  }
  const colors=kind%3===0?['#fff0ae','#ffa927','#cf4f19']:kind%3===1?['#b2efff','#39a9d9','#2856a1']:['#ffdbc0','#f57845','#c13735'];
  ctx.fillStyle=colors[1];ctx.strokeStyle=colors[2];ctx.lineWidth=.8;
  ctx.beginPath();ctx.moveTo(-18,0);ctx.quadraticCurveTo(-33,-18-flick*4,-38,-13);ctx.quadraticCurveTo(-29,0,-38,14);ctx.quadraticCurveTo(-32,18+flick*4,-18,2);ctx.fill();ctx.stroke();
  ctx.globalAlpha=.7;ctx.beginPath();ctx.moveTo(-10,-8);ctx.quadraticCurveTo(-7,-27,6,-14);ctx.lineTo(15,-6);ctx.fill();ctx.beginPath();ctx.moveTo(-3,9);ctx.lineTo(-7,25);ctx.lineTo(13,8);ctx.fill();ctx.globalAlpha=1;
  const body=ctx.createLinearGradient(0,-15,0,15);body.addColorStop(0,colors[0]);body.addColorStop(.42,colors[1]);body.addColorStop(1,colors[2]);ellipse(ctx,0,0,24,13,body);
  if(species===4){ctx.save();ctx.beginPath();ctx.ellipse(0,0,24,13,0,0,TAU);ctx.clip();ctx.fillStyle='#fff3d8';for(const x of[-13,1,13]){ctx.fillRect(x,-15,4,30);}ctx.restore();}
  ctx.strokeStyle=colors[2]+'77';for(let i=-12;i<16;i+=6){ctx.beginPath();ctx.ellipse(i,0,3,9,0,-1.1,1.1);ctx.stroke();}
  ctx.strokeStyle=colors[0]+'aa';ctx.beginPath();ctx.arc(8,0,8,-1.2,1.2);ctx.stroke();ellipse(ctx,15,-3,3.5,3.5,'#eaf3ce');ellipse(ctx,16,-3,2,2,'#0a1721');ellipse(ctx,16.6,-3.7,.7,.7,'white');
  ctx.fillStyle=colors[0]+'aa';ctx.beginPath();ctx.moveTo(0,0);ctx.quadraticCurveTo(-9,8+flick*3,3,9);ctx.closePath();ctx.fill();ctx.restore();
}
export function drawFishbowl(ctx,w,h,t,density,interaction){
  const cx=w*.5,cy=h*.47,r=Math.min(w*.36,h*.43);
  const bg=ctx.createRadialGradient(cx,cy,0,cx,cy,Math.max(w,h)*.7);bg.addColorStop(0,'#17303b');bg.addColorStop(.6,'#080f1b');bg.addColorStop(1,'#02050c');ctx.fillStyle=bg;ctx.fillRect(0,0,w,h);
  const floor=cy+r*.88;const wood=ctx.createLinearGradient(0,floor,0,h);wood.addColorStop(0,'#40352d');wood.addColorStop(1,'#100f13');ctx.fillStyle=wood;ctx.fillRect(0,floor,w,h-floor);
  ctx.strokeStyle='#b9976710';for(let i=0;i<14;i++){ctx.beginPath();ctx.moveTo(0,floor+i*7);ctx.bezierCurveTo(w*.3,floor+i*7-6,w*.7,floor+i*7+5,w,floor+i*7);ctx.stroke();}
  ellipse(ctx,cx,floor+r*.1,r*1.12,r*.12,'#00000088');
  ctx.save();bowlPath(ctx,cx,cy,r);ctx.clip();
  const water=ctx.createLinearGradient(0,cy-r,0,cy+r);water.addColorStop(0,'#276b80');water.addColorStop(.3,'#125268');water.addColorStop(.7,'#073747');water.addColorStop(1,'#092a35');ctx.fillStyle=water;ctx.fillRect(cx-r*1.1,cy-r,r*2.2,r*2);
  // Soft shafts of light and rippling caustics.
  ctx.save();ctx.globalCompositeOperation='screen';for(let i=0;i<5;i++){ctx.fillStyle='#77e7e709';ctx.beginPath();const x=cx-r*.6+i*r*.3+Math.sin(t*.4+i)*r*.05;ctx.moveTo(x,cy-r);ctx.lineTo(x+r*.22,cy+r);ctx.lineTo(x+r*.5,cy+r);ctx.lineTo(x+r*.12,cy-r);ctx.fill();}ctx.restore();
  const gravelY=cy+r*.66;ellipse(ctx,cx,gravelY+r*.17,r*.9,r*.25,'#80775a');
  for(let i=0;i<240;i++){const x=cx+(noise(i+83)*2-1)*r;const y=gravelY+noise(i+200)*r*.24;const shade=Math.floor(noise(i+500)*60+65);ellipse(ctx,x,y,r*(.011+noise(i)*.016),r*.012,`rgb(${shade+28},${shade+15},${shade})`);}
  for(let p=0;p<7;p++){const x=cx+(p<4?-.65+p*.085:.49+(p-4)*.08)*r;for(let j=0;j<5;j++){const length=r*(.25+noise(p*7+j)*.48);ctx.beginPath();ctx.moveTo(x+j*r*.018,gravelY+r*.08);const sway=Math.sin(t*1.2+p+j*.4)*r*.055;ctx.bezierCurveTo(x-r*.08,gravelY-length*.4,x+r*.11+sway,gravelY-length*.7,x+sway,gravelY-length);ctx.strokeStyle=['#427d46','#66a15c','#2c6348'][j%3];ctx.lineWidth=r*(.018+noise(j+p)*.014);ctx.lineCap='round';ctx.stroke();}}
  // A tiny terracotta hideout on the gravel.
  ctx.save();ctx.translate(cx+r*.3,gravelY);ctx.rotate(-.18);ctx.fillStyle='#a96748';ctx.beginPath();ctx.roundRect(-r*.12,-r*.21,r*.25,r*.25,r*.025);ctx.fill();ellipse(ctx,0,-r*.08,r*.072,r*.1,'#362b28');ctx.strokeStyle='#dc9c66';ctx.lineWidth=r*.018;ctx.strokeRect(-r*.12,-r*.21,r*.25,r*.02);ctx.restore();
  const age=interaction?t-interaction.time:99;
  const foodX=interaction?Math.max(cx-r*.55,Math.min(cx+r*.55,interaction.x*w)):cx;
  const foodY=Math.min(gravelY-r*.12,cy-r*.48+age*r*.035);
  const attraction=age<14?(1-Math.exp(-age*1.4))*Math.max(0,1-age/14)*.85:0;
  const count=Math.ceil(7*density);for(let i=0;i<count;i++){const a=t*(.15+noise(i+20)*.16)+i*2.4;let x=cx+Math.sin(a)*r*(.35+noise(i+61)*.29);let y=cy+r*(-.12+Math.sin(a*.63+i)*.38);const oldX=x;x=x*(1-attraction)+(foodX+Math.sin(t+i)*r*.13)*attraction;y=y*(1-attraction)+(foodY+Math.cos(t*.8+i)*r*.12)*attraction;const dir=attraction>.35?(foodX>oldX?1:-1):(Math.cos(a)>0?1:-1);const turn=Math.max(.25,Math.min(1,Math.abs(Math.cos(a))*4+attraction));fish(ctx,x,y,r/210*(.65+noise(i+19)*.5),dir,i,t,i,turn);}
  drawInhabitants(ctx,cx,cy,r,t);
  if(age<14){ctx.globalAlpha=Math.min(1,(14-age)/3);for(let i=0;i<14;i++){ellipse(ctx,foodX+(noise(i+31)-.5)*r*.19,foodY+noise(i+100)*r*.13,r*.008,r*.006,i%2?'#e7c083':'#ad763a');}ctx.globalAlpha=1;}
  for(let i=0;i<24*density;i++){const phase=wrap(t*(.06+noise(i)*.06)+noise(i+99),1);const x=cx+r*(.5+Math.sin(i*9)*.12+Math.sin(t+i)*.025);const y=gravelY-phase*r*1.45;const size=r*(.008+noise(i+66)*.012);ctx.strokeStyle='#b8edf86b';ctx.lineWidth=Math.max(.7,r*.004);ctx.beginPath();ctx.arc(x,y,size,0,TAU);ctx.stroke();ellipse(ctx,x-size*.3,y-size*.3,size*.2,size*.2,'#ddffffa0');}
  // The waterline remains behind the glass reflections.
  ellipse(ctx,cx,cy-r*.67,r*.61,r*.065,'#8fd9dc28');ctx.strokeStyle='#b1fbff55';ctx.lineWidth=r*.005;ctx.beginPath();ctx.ellipse(cx,cy-r*.67,r*.61,r*.065,0,0,TAU);ctx.stroke();ctx.restore();
  const glass=ctx.createLinearGradient(cx-r,cy,cx+r,cy);glass.addColorStop(0,'#b3f3ffb0');glass.addColorStop(.15,'#72a5b245');glass.addColorStop(.5,'#9bdeea15');glass.addColorStop(.85,'#9fdbf54a');glass.addColorStop(1,'#d2f6ffb0');ctx.strokeStyle=glass;ctx.lineWidth=r*.013;bowlPath(ctx,cx,cy,r);ctx.stroke();
  ctx.strokeStyle='#e5fcff55';ctx.lineWidth=r*.025;ctx.lineCap='round';ctx.beginPath();ctx.moveTo(cx-r*.72,cy-r*.37);ctx.bezierCurveTo(cx-r*.88,cy-r*.16,cx-r*.87,cy+r*.08,cx-r*.78,cy+r*.3);ctx.stroke();ctx.strokeStyle='#e5fcff20';ctx.lineWidth=r*.06;ctx.beginPath();ctx.moveTo(cx+r*.77,cy-r*.27);ctx.quadraticCurveTo(cx+r*.93,cy+r*.1,cx+r*.66,cy+r*.52);ctx.stroke();
  ellipse(ctx,cx,cy-r*.8,r*.53,r*.075,'#94c5cc22');ctx.strokeStyle='#b4e0e48c';ctx.lineWidth=r*.014;ctx.beginPath();ctx.ellipse(cx,cy-r*.8,r*.53,r*.075,0,0,TAU);ctx.stroke();ellipse(ctx,cx,cy+r*.84,r*.48,r*.035,'#b9e3dc33');
}

function drawInhabitants(ctx,cx,cy,r,t){
  // A gently pulsing jellyfish in the upper left.
  ctx.save();ctx.translate(cx-r*.47+Math.sin(t*.4)*r*.055,cy-r*.35+Math.sin(t*.8)*r*.05);ctx.scale(r/200,r/200);
  const pulse=1+Math.sin(t*2)*.1;ctx.scale(pulse,1/pulse);ctx.fillStyle='#d9a9edaa';ctx.beginPath();ctx.ellipse(0,0,17,13,0,Math.PI,TAU);ctx.quadraticCurveTo(0,8,-17,0);ctx.fill();ctx.strokeStyle='#e2b8f2aa';ctx.lineWidth=1.2;
  for(let i=0;i<5;i++){ctx.beginPath();ctx.moveTo(-12+i*6,1);ctx.bezierCurveTo(-15+i*6+Math.sin(t*2+i)*4,12,-8+i*6,20,-12+i*6+Math.sin(t+i)*5,30);ctx.stroke();}ellipse(ctx,-5,-6,3,2,'#fff0ff77');ctx.restore();
  // A curled seahorse, with a different silhouette and swimming rhythm.
  ctx.save();ctx.translate(cx+r*.63+Math.sin(t*.35)*r*.035,cy+r*.1+Math.sin(t*.9)*r*.055);ctx.scale(r/220,r/220);ctx.strokeStyle='#dfa36c';ctx.lineWidth=8;ctx.lineCap='round';ctx.beginPath();ctx.moveTo(-1,-14);ctx.bezierCurveTo(-13,0,10,7,2,24);ctx.bezierCurveTo(-8,39,-19,24,-8,23);ctx.stroke();ellipse(ctx,0,-19,10,9,'#e5b980');ctx.fillStyle='#e5b980';ctx.fillRect(3,-22,15,5);ellipse(ctx,2,-22,2,2,'#172b26');ctx.strokeStyle='#9a724f';ctx.lineWidth=1;for(let i=0;i<5;i++){ctx.beginPath();ctx.moveTo(-6,-9+i*5);ctx.lineTo(3,-8+i*5);ctx.stroke();}ctx.restore();
  // A small crab patrols the gravel instead of swimming with the fish.
  ctx.save();ctx.translate(cx-r*.3+Math.sin(t*.2)*r*.12,cy+r*.72);ctx.scale(r/190,r/190);ctx.strokeStyle='#d36d45';ctx.lineWidth=2;
  for(let side of[-1,1]){for(let j=0;j<3;j++){ctx.beginPath();ctx.moveTo(side*7,0);ctx.lineTo(side*(14+j*2),4+j*2+Math.sin(t*5+j)*2);ctx.lineTo(side*(18+j*2),9);ctx.stroke();}ctx.beginPath();ctx.moveTo(side*8,-3);ctx.lineTo(side*17,-10+Math.sin(t*2)*2);ctx.stroke();ellipse(ctx,side*18,-12+Math.sin(t*2)*2,5,4,'#f39256');}
  ellipse(ctx,0,0,12,7,'#e47e45');for(let side of[-1,1]){ctx.fillStyle='#efbe80';ctx.fillRect(side*5-1,-10,2,6);ellipse(ctx,side*5,-11,2,2,'#101e24');}ctx.restore();
  // A five-armed starfish rests on the right side of the bowl.
  ctx.save();ctx.translate(cx+r*.62,cy+r*.67);ctx.rotate(.2);ctx.scale(r*.06,r*.06);ctx.fillStyle='#d98a89';ctx.beginPath();for(let j=0;j<10;j++){const a=j/10*TAU-Math.PI/2,rad=j%2?.4:1;ctx.lineTo(Math.cos(a)*rad,Math.sin(a)*rad);}ctx.closePath();ctx.fill();ctx.restore();
}
