# Idle Hours

A nostalgic browser screensaver collection, built with vanilla JavaScript and Vite. No runtime dependencies, external assets, accounts, or backend.

## Run locally

```sh
npm install
npm run dev
```

Open http://127.0.0.1:5173. Use `npm run build` for a production build and `npm run preview` to preview it.

## The collection

- **Asteroid field** — procedurally generated, flat-shaded WebGL rocks flying toward the camera.
- **Starfield** — a perspective WebGL starfield.
- **Mystify** — layered neon polygon trails on Canvas 2D.
- **Digital rain** — animated phosphor-green character streams on Canvas 2D.
- **3D Pipes** — growing multicolored WebGL pipe networks with thick tubes, ball joints, and pixelated rendering.
- **Flying toasters** — original procedurally drawn chrome toasters with flapping feathered wings and drifting buttered toast. Toasters bounce off the scene edges. Click for a toast burst.
- **Fishbowl** — an animated glass bowl with goldfish, angelfish, neon tetras, puffers, clownfish, a jellyfish, seahorse, crab, starfish, plants, bubbles, gravel, and underwater lighting. Click to drop food and attract the fish.

Browse by category, select an animated carousel preview, then choose **Space out** to open its detail viewer. Adjust speed and density, pause/resume, or go fullscreen. Escape returns from fullscreen. Screensavers can be linked directly with `/#view/asteroids`, `/#view/starfield`, `/#view/mystify`, `/#view/matrix`, `/#view/pipes`, `/#view/toasters`, or `/#view/fishbowl`.

`src/savers.js` owns rendering and GPU resource cleanup. `src/nostalgia.js` draws the toasters and fishbowl. `src/main.js` owns the gallery and viewer. `src/style.css` owns the responsive retro desktop appearance. Motion is slowed when the operating system requests reduced motion; animation stops advancing in background tabs. Browsers without WebGL receive a simple Canvas 2D starfield fallback for 3D scenes.

The toasters, fishbowl, and pipes render at a deliberately low internal resolution and use nearest-neighbor display scaling for a blocky period look.

## Hidden arcade

Three discoverable extras hide behind the logo star (pixel rave), visitor counter (Pong versus an AI), and coffee cup (falling-block puzzle). Hover hints and a footer clue point the way. Games support keyboard and on-screen touch controls; Pong also follows mouse or touch movement. Close the window or press Escape to return.
