// "3D Pipes": shiny pipes grow through a 3D grid, turning at ball joints,
// until the space fills up and it starts over.
import { getGL, createProgram, runLoop } from "../gl.js";

const VS = `
attribute vec3 aPos;
attribute vec3 aNormal;
uniform mat3 uBasis;
uniform vec3 uScale;
uniform vec3 uCenter;
uniform mat4 uProj;
uniform float uAngle;
varying vec3 vN;
varying vec3 vP;
vec3 spin(vec3 v) {
  float c = cos(uAngle), s = sin(uAngle);
  return vec3(c * v.x + s * v.z, v.y, -s * v.x + c * v.z);
}
void main() {
  vec3 w = spin(uBasis * (aPos * uScale) + uCenter);
  vN = spin(uBasis * aNormal);
  vP = w;
  gl_Position = uProj * vec4(w - vec3(0.0, 0.0, 17.0), 1.0);
}`;

const FS = `
precision mediump float;
uniform vec3 uColor;
varying vec3 vN;
varying vec3 vP;
void main() {
  vec3 n = normalize(vN);
  vec3 L = normalize(vec3(0.5, 0.8, 0.6));
  vec3 V = normalize(vec3(0.0, 0.0, 17.0) - vP);
  float diff = max(dot(n, L), 0.0);
  float spec = pow(max(dot(reflect(-L, n), V), 0.0), 24.0);
  gl_FragColor = vec4(uColor * (0.18 + 0.82 * diff) + vec3(spec * 0.7), 1.0);
}`;

// Interleaved [x,y,z,nx,ny,nz] triangles.
function cylinderMesh(seg = 12) {
  const out = [];
  for (let i = 0; i < seg; i++) {
    const a0 = (i / seg) * Math.PI * 2, a1 = ((i + 1) / seg) * Math.PI * 2;
    const [c0, s0, c1, s1] = [Math.cos(a0), Math.sin(a0), Math.cos(a1), Math.sin(a1)];
    const v = (c, s, z) => [c, s, z, c, s, 0];
    out.push(...v(c0, s0, -1), ...v(c1, s1, -1), ...v(c1, s1, 1),
      ...v(c0, s0, -1), ...v(c1, s1, 1), ...v(c0, s0, 1));
  }
  return new Float32Array(out);
}

function sphereMesh(lat = 8, lon = 12) {
  const p = (i, j) => {
    const th = (i / lat) * Math.PI, ph = (j / lon) * Math.PI * 2;
    const x = Math.sin(th) * Math.cos(ph), y = Math.cos(th), z = Math.sin(th) * Math.sin(ph);
    return [x, y, z, x, y, z];
  };
  const out = [];
  for (let i = 0; i < lat; i++) for (let j = 0; j < lon; j++) {
    out.push(...p(i, j), ...p(i + 1, j), ...p(i + 1, j + 1), ...p(i, j), ...p(i + 1, j + 1), ...p(i, j + 1));
  }
  return new Float32Array(out);
}

// Torus around the z axis: ring radius 1, tube radius `tube`.
function torusMesh(tube = 0.3, seg = 16, sides = 8) {
  const p = (i, j) => {
    const u = (i / seg) * Math.PI * 2, v = (j / sides) * Math.PI * 2;
    const nx = Math.cos(v) * Math.cos(u), ny = Math.cos(v) * Math.sin(u), nz = Math.sin(v);
    return [Math.cos(u) + tube * nx, Math.sin(u) + tube * ny, tube * nz, nx, ny, nz];
  };
  const out = [];
  for (let i = 0; i < seg; i++) for (let j = 0; j < sides; j++) {
    out.push(...p(i, j), ...p(i + 1, j), ...p(i + 1, j + 1), ...p(i, j), ...p(i + 1, j + 1), ...p(i, j + 1));
  }
  return new Float32Array(out);
}

// The classic easter egg: very occasionally a joint is a teapot instead of a ball.
const TEAPOT_CHANCE = 1 / 150;
const S2 = Math.SQRT1_2;
const SPOUT_BASIS = new Float32Array([0, 0, 1, S2, -S2, 0, S2, S2, 0]); // z axis -> up and to the right

function perspective(fovy, aspect, near, far) {
  const f = 1 / Math.tan(fovy / 2);
  return new Float32Array([f / aspect, 0, 0, 0, 0, f, 0, 0, 0, 0, (far + near) / (near - far), -1, 0, 0, (2 * far * near) / (near - far), 0]);
}

const N = 10;            // grid cells per side
const RADIUS = 0.22;
const MAX_SEGMENTS = 700;
const DIRS = [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]];
const COLORS = [[0.9, 0.1, 0.1], [0.1, 0.7, 0.1], [0.15, 0.3, 1], [1, 0.8, 0.1], [0.8, 0.2, 0.9], [0.1, 0.8, 0.9], [0.85, 0.85, 0.85]];
const IDENTITY = new Float32Array([1, 0, 0, 0, 1, 0, 0, 0, 1]);

// Basis whose third column is the pipe's axis, so the mesh's z runs along it.
function basisFor(dir) {
  const a = dir.findIndex((d) => d !== 0);
  const e = (k) => [0, 1, 2].map((m) => (m === k ? 1 : 0));
  return new Float32Array([...e((a + 1) % 3), ...e((a + 2) % 3), ...e(a)]);
}
const BASES = DIRS.map(basisFor);

export default {
  id: "pipes",
  name: "3D Pipes",
  blurb: "The PLUMBING of the FUTURE. Keep ur eyes peeled 4 the teapot!!",
  create(canvas, opts) {
    const gl = getGL(canvas);
    const prog = createProgram(gl, VS, FS);
    const loc = (n) => gl.getUniformLocation(prog, n);
    const U = Object.fromEntries(["uBasis", "uScale", "uCenter", "uProj", "uAngle", "uColor"].map((n) => [n, loc(n)]));
    const aPos = gl.getAttribLocation(prog, "aPos");
    const aNormal = gl.getAttribLocation(prog, "aNormal");
    const mesh = (data) => {
      const buf = gl.createBuffer();
      gl.bindBuffer(gl.ARRAY_BUFFER, buf);
      gl.bufferData(gl.ARRAY_BUFFER, data, gl.STATIC_DRAW);
      return { buf, count: data.length / 6 };
    };
    const cyl = mesh(cylinderMesh());
    const sph = mesh(sphereMesh());
    const tor = mesh(torusMesh());
    // Cheat code: ?teapot makes every joint a teapot.
    const teapotChance = new URLSearchParams(location.search).has("teapot") ? 1 : TEAPOT_CHANCE;

    const joint = (center, color) => {
      if (Math.random() >= teapotChance) {
        pieces.push({ mesh: sph, center, basis: IDENTITY, scale: [RADIUS * 1.25, RADIUS * 1.25, RADIUS * 1.25], color });
        return;
      }
      const at = (dx, dy) => [center[0] + dx, center[1] + dy, center[2]];
      pieces.push(
        { mesh: sph, center: at(0, 0), basis: IDENTITY, scale: [0.42, 0.32, 0.42], color },             // body
        { mesh: sph, center: at(0, 0.3), basis: IDENTITY, scale: [0.2, 0.08, 0.2], color },             // lid
        { mesh: sph, center: at(0, 0.4), basis: IDENTITY, scale: [0.06, 0.06, 0.06], color },           // knob
        { mesh: cyl, center: at(0.5, 0.12), basis: SPOUT_BASIS, scale: [0.06, 0.06, 0.2], color },      // spout
        { mesh: tor, center: at(-0.42, 0.04), basis: IDENTITY, scale: [0.16, 0.16, 0.16], color },     // handle
      );
    };

    let occupied, pieces, pipes;
    const key = (p) => p.join(",");
    const world = (p) => p.map((c) => c - (N - 1) / 2);
    const inside = (p) => p.every((c) => c >= 0 && c < N);

    const startPipe = () => {
      for (let tries = 0; tries < 50; tries++) {
        const pos = [0, 0, 0].map(() => Math.floor(Math.random() * N));
        if (occupied.has(key(pos))) continue;
        occupied.add(key(pos));
        const pipe = { pos, dir: Math.floor(Math.random() * 6), color: COLORS[Math.floor(Math.random() * COLORS.length)] };
        pieces.push({ mesh: sph, center: world(pos), basis: IDENTITY, scale: [RADIUS * 1.5, RADIUS * 1.5, RADIUS * 1.5], color: pipe.color });
        return pipe;
      }
      return null;
    };
    const reset = () => {
      occupied = new Set();
      pieces = [];
      pipes = [startPipe(), startPipe(), startPipe()];
    };
    reset();

    const grow = (pipe) => {
      const next = (d) => pipe.pos.map((c, k) => c + DIRS[d][k]);
      const free = (d) => inside(next(d)) && !occupied.has(key(next(d)));
      let d = pipe.dir;
      if (!free(d) || Math.random() < 0.25) {
        const options = DIRS.map((_, i) => i).filter(free);
        if (!options.length) return startPipe(); // boxed in: start a new pipe elsewhere
        const turned = options[Math.floor(Math.random() * options.length)];
        if (turned !== d) joint(world(pipe.pos), pipe.color);
        d = turned;
      }
      const to = next(d);
      const from = world(pipe.pos);
      pieces.push({
        mesh: cyl, basis: BASES[d], scale: [RADIUS, RADIUS, 0.5], color: pipe.color,
        center: from.map((c, k) => c + DIRS[d][k] * 0.5),
      });
      occupied.add(key(to));
      pipe.pos = to;
      pipe.dir = d;
      return pipe;
    };

    let acc = 0, t = 0;
    return runLoop(gl, (dt) => {
      const step = dt * (opts?.speed ?? 1);
      t += step;
      acc += step;
      while (acc > 0.06) {
        acc -= 0.06;
        pipes = pipes.map((p) => (p ? grow(p) : startPipe()));
        if (pieces.length > MAX_SEGMENTS || pipes.every((p) => !p)) reset();
      }

      gl.clearColor(0, 0, 0, 1);
      gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
      gl.enable(gl.DEPTH_TEST);
      gl.disable(gl.BLEND);
      gl.useProgram(prog);
      gl.uniformMatrix4fv(U.uProj, false, perspective(0.85, gl.canvas.width / gl.canvas.height, 1, 60));
      gl.uniform1f(U.uAngle, t * 0.1);
      let bound = null;
      for (const p of pieces) {
        if (bound !== p.mesh) {
          bound = p.mesh;
          gl.bindBuffer(gl.ARRAY_BUFFER, p.mesh.buf);
          gl.enableVertexAttribArray(aPos);
          gl.vertexAttribPointer(aPos, 3, gl.FLOAT, false, 24, 0);
          gl.enableVertexAttribArray(aNormal);
          gl.vertexAttribPointer(aNormal, 3, gl.FLOAT, false, 24, 12);
        }
        gl.uniformMatrix3fv(U.uBasis, false, p.basis);
        gl.uniform3fv(U.uScale, p.scale);
        gl.uniform3fv(U.uCenter, p.center);
        gl.uniform3fv(U.uColor, p.color);
        gl.drawArrays(gl.TRIANGLES, 0, p.mesh.count);
      }
    });
  },
};
