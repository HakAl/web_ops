// Demoscene-style plasma, posterized down to a 16-ish colour palette for that VGA look.
import { fragmentSaver } from "../gl.js";

export default {
  id: "plasma",
  name: "Psychedelic Plasma",
  blurb: "256 colors of pure GROOVY. Requires a Pentium!!",
  create: fragmentSaver(`
    precision mediump float;
    uniform float uTime;
    uniform vec2 uRes;
    void main() {
      vec2 uv = (gl_FragCoord.xy - 0.5 * uRes) / uRes.y * 4.0;
      float t = uTime;
      float v = sin(uv.x + t)
              + sin((uv.y + t) * 0.5)
              + sin((uv.x + uv.y + t) * 0.5)
              + sin(length(uv + vec2(sin(t * 0.3), cos(t * 0.5)) * 2.0) + t);
      vec3 col = 0.5 + 0.5 * cos(3.14159 * v + vec3(0.0, 2.0, 4.0));
      col = floor(col * 4.0) / 4.0; // posterize
      gl_FragColor = vec4(col, 1.0);
    }`),
};
