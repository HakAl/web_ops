// "Beziers": NT-era bouncing control points drawn as smooth cubic curves with echoes.
import { getGL, createProgram, runLoop } from "../gl.js";

const VS = `
attribute vec2 aPos;
void main() { gl_Position = vec4(aPos, 0.0, 1.0); }`;

const FS = `
precision mediump float;
uniform vec4 uColor;
void main() { gl_FragColor = uColor; }`;

const CURVES = 3;   // cubic segments chained into a closed loop
const SEGMENTS = 24; // line segments per cubic
const ECHOES = 10;

function cubic(p0, p1, p2, p3, t) {
  const u = 1 - t;
  return u * u * u * p0 + 3 * u * u * t * p1 + 3 * u * t * t * p2 + t * t * t * p3;
}

export default {
  id: "beziers",
  name: "Beziers",
  blurb: "Curvy lines 4 professionals. As seen on Windows NT!",
  create(canvas, opts) {
    const gl = getGL(canvas);
    const prog = createProgram(gl, VS, FS);
    const aPos = gl.getAttribLocation(prog, "aPos");
    const uColor = gl.getUniformLocation(prog, "uColor");
    const buf = gl.createBuffer();

    const pts = Array.from({ length: CURVES * 3 }, () => ({
      x: Math.random() * 2 - 1,
      y: Math.random() * 2 - 1,
      vx: (Math.random() - 0.5) * 1.4,
      vy: (Math.random() - 0.5) * 1.4,
    }));
    const history = [];
    let hue = Math.random() * 6;
    let acc = 0;

    // Control points p[3i] are on-curve; p[3i+1], p[3i+2] are handles.
    const tessellate = () => {
      const out = [];
      const n = pts.length;
      for (let c = 0; c < CURVES; c++) {
        const a = pts[c * 3], b = pts[c * 3 + 1], d = pts[c * 3 + 2], e = pts[(c * 3 + 3) % n];
        for (let s = 0; s < SEGMENTS; s++) {
          const t = s / SEGMENTS;
          out.push(cubic(a.x, b.x, d.x, e.x, t), cubic(a.y, b.y, d.y, e.y, t));
        }
      }
      return new Float32Array(out);
    };

    return runLoop(gl, (dt) => {
      const step = dt * (opts?.speed ?? 1);
      for (const p of pts) {
        p.x += p.vx * step;
        p.y += p.vy * step;
        if (Math.abs(p.x) > 1) { p.vx *= -1; p.x = Math.sign(p.x); }
        if (Math.abs(p.y) > 1) { p.vy *= -1; p.y = Math.sign(p.y); }
      }
      hue += step * 0.4;
      acc += step;
      if (acc > 0.03) {
        acc = 0;
        history.unshift(tessellate());
        history.length = Math.min(history.length, ECHOES);
      }

      gl.clearColor(0, 0, 0, 1);
      gl.clear(gl.COLOR_BUFFER_BIT);
      gl.useProgram(prog);
      gl.bindBuffer(gl.ARRAY_BUFFER, buf);
      gl.enableVertexAttribArray(aPos);
      gl.vertexAttribPointer(aPos, 2, gl.FLOAT, false, 0, 0);
      history.forEach((verts, i) => {
        const f = 1 - i / ECHOES;
        const h = hue + i * 0.15;
        gl.uniform4f(uColor,
          f * (0.5 + 0.5 * Math.sin(h)),
          f * (0.5 + 0.5 * Math.sin(h + 2.1)),
          f * (0.5 + 0.5 * Math.sin(h + 4.2)), 1);
        gl.bufferData(gl.ARRAY_BUFFER, verts, gl.DYNAMIC_DRAW);
        gl.drawArrays(gl.LINE_LOOP, 0, verts.length / 2);
      });
    });
  },
};
