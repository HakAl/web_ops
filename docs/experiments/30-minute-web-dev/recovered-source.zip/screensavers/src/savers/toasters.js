// Tribute to the After Dark classic: winged toasters and toast drifting
// diagonally down-left across the night. Art is drawn procedurally.
import { getGL, runLoop } from "../gl.js";
import { createSpriteBatch } from "../sprites.js";

const WING_LIFT = [-1.0, -0.45, 0.1, 0.55]; // radians, frame 0 = wings up
const FLAP = [0, 1, 2, 3, 2, 1];             // ping-pong frame order

function wing(ctx, color, edge) {
  ctx.scale(0.85, 0.85);
  ctx.fillStyle = color;
  ctx.strokeStyle = edge;
  ctx.lineWidth = 2;
  for (let k = 3; k >= 0; k--) {
    ctx.beginPath();
    ctx.ellipse(16 + k * 9, -4 + k * 3, 24 - k * 3, 7, -0.25, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
  }
}

function paintToaster(frame) {
  return (ctx) => {
    const lift = WING_LIFT[frame];
    ctx.translate(-12, 6); // leave room in the cell for the wing tips
    // Far wing, peeking out behind the body.
    ctx.save();
    ctx.translate(76, 58);
    ctx.rotate(lift * 0.8 - 0.2);
    wing(ctx, "#c8c8d0", "#777");
    ctx.restore();

    // Chrome body.
    const g = ctx.createLinearGradient(0, 52, 0, 110);
    g.addColorStop(0, "#ffffff");
    g.addColorStop(0.35, "#c9ccd4");
    g.addColorStop(0.5, "#f6f6f6");
    g.addColorStop(1, "#7d808a");
    ctx.fillStyle = g;
    ctx.strokeStyle = "#444";
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.roundRect(24, 50, 80, 58, 12);
    ctx.fill();
    ctx.stroke();
    // Toast peeking out of the slot.
    ctx.fillStyle = "#d9a050";
    ctx.fillRect(40, 42, 34, 9);
    ctx.strokeStyle = "#7a4a18";
    ctx.lineWidth = 2;
    ctx.strokeRect(40, 42, 34, 9);
    // Base, lever, shine.
    ctx.fillStyle = "#333";
    ctx.fillRect(26, 104, 76, 6);
    ctx.fillRect(16, 70, 10, 7);
    ctx.fillStyle = "rgba(255,255,255,0.8)";
    ctx.fillRect(32, 60, 50, 3);

    // Near wing.
    ctx.save();
    ctx.translate(70, 64);
    ctx.rotate(lift);
    wing(ctx, "#ffffff", "#666");
    ctx.restore();
  };
}

function paintToast(crumb, crust) {
  return (ctx) => {
    ctx.save();
    ctx.translate(64, 64);
    ctx.rotate(-0.2);
    ctx.beginPath();
    ctx.moveTo(-30, 34);
    ctx.lineTo(-30, -14);
    ctx.bezierCurveTo(-42, -40, -10, -44, 0, -32);
    ctx.bezierCurveTo(10, -44, 42, -40, 30, -14);
    ctx.lineTo(30, 34);
    ctx.closePath();
    ctx.fillStyle = crumb;
    ctx.fill();
    ctx.lineWidth = 7;
    ctx.strokeStyle = crust;
    ctx.stroke();
    ctx.restore();
  };
}

const painters = [
  paintToaster(0), paintToaster(1), paintToaster(2), paintToaster(3),
  paintToast("#f0c879", "#a5651f"), // golden
  paintToast("#b8742c", "#5a300d"), // well done
];

const COUNT = 16;
const H = 600;

export default {
  id: "toasters",
  name: "Flying Toasters (tribute)",
  blurb: "Toasters. With WINGS. Breakfast is airborne!!!",
  create(canvas, opts) {
    const gl = getGL(canvas);
    const batch = createSpriteBatch(gl, painters);
    let W = H * (canvas.clientWidth / canvas.clientHeight || 1.5);

    const respawn = (o, anywhere) => {
      o.toast = Math.random() < 0.3;
      o.shade = Math.random() < 0.5 ? 4 : 5;
      o.size = 60 + Math.random() * 70;
      o.v = 60 + o.size * 0.9; // bigger = closer = faster
      o.phase = Math.random() * 6;
      o.dir = Math.random() < 0.7 ? -1 : 1; // mostly the classic leftward flight
      o.x = o.size / 2 + Math.random() * (W - o.size);
      o.y = anywhere ? Math.random() * H : -o.size; // new ones drop in from the top
    };
    const fliers = Array.from({ length: COUNT }, () => {
      const o = {};
      respawn(o, true);
      return o;
    });

    let t = 0;
    return runLoop(gl, (dt) => {
      W = H * (gl.canvas.width / gl.canvas.height);
      const step = dt * (opts?.speed ?? 1);
      t += step;
      for (const o of fliers) {
        o.x += o.dir * o.v * step;
        o.y += o.v * 0.5 * step;
        // Bounce off the side walls; only falling out the bottom respawns.
        const half = o.size / 2;
        if (o.x < half) { o.x = half; o.dir = 1; }
        if (o.x > W - half) { o.x = W - half; o.dir = -1; }
        if (o.y > H + o.size) respawn(o, false);
      }
      fliers.sort((a, b) => a.size - b.size); // far (small) first

      gl.clearColor(0, 0, 0, 1);
      gl.clear(gl.COLOR_BUFFER_BIT);
      batch.draw(fliers.map((o) => ({
        i: o.toast ? o.shade : FLAP[Math.floor(t * 10 + o.phase) % FLAP.length],
        x: o.x, y: o.y, w: o.size, h: o.size, flip: o.dir > 0, // art faces left
      })), W, H);
    });
  },
};
