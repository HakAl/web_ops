// Fishbowl: a little reef with assorted fish, pufferfish, angelfish, drifting
// jellyfish, seahorses, scuttling crabs and starfish, plus bubbles, swaying
// seaweed and light rays. All art is drawn procedurally into the sprite atlas.
import { getGL, runLoop } from "../gl.js";
import { createSpriteBatch } from "../sprites.js";

const FISH_COLORS = [
  ["#ff8c1a", "#ffffff"], // clownfish-ish
  ["#ffe14d", "#2b6cff"],
  ["#ff4fa3", "#ffd0e8"],
  ["#3ad1c8", "#0b4f6c"],
];

function blob(ctx, x, y, rx, ry, fill, stroke = "#222", lw = 3) {
  ctx.beginPath();
  ctx.ellipse(x, y, rx, ry, 0, 0, Math.PI * 2);
  if (fill) {
    ctx.fillStyle = fill;
    ctx.fill();
  }
  if (stroke) {
    ctx.lineWidth = lw;
    ctx.strokeStyle = stroke;
    ctx.stroke();
  }
}

function eye(ctx, x, y, r = 7) {
  blob(ctx, x, y, r, r, "#fff", null);
  blob(ctx, x - r * 0.3, y, r / 2, r / 2, "#000", null);
}

function paintWater(ctx) {
  const g = ctx.createLinearGradient(0, 0, 0, 128);
  g.addColorStop(0, "#3aa6e8");
  g.addColorStop(1, "#031c40");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, 128, 128);
}

function paintSand(ctx) {
  ctx.fillStyle = "#d8c28a";
  ctx.beginPath();
  ctx.moveTo(0, 128);
  for (let x = 0; x <= 128; x += 8) ctx.lineTo(x, 30 + Math.sin(x * 0.15) * 8);
  ctx.lineTo(128, 128);
  ctx.fill();
  for (let i = 0; i < 60; i++) {
    ctx.fillStyle = Math.random() < 0.5 ? "#b89f62" : "#efe0b0";
    ctx.fillRect(Math.random() * 128, 45 + Math.random() * 83, 5, 5);
  }
}

function paintRay(ctx) {
  const g = ctx.createLinearGradient(0, 0, 128, 0);
  g.addColorStop(0, "rgba(255,255,255,0)");
  g.addColorStop(0.5, "rgba(255,255,255,1)");
  g.addColorStop(1, "rgba(255,255,255,0)");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, 128, 128);
  ctx.globalCompositeOperation = "destination-in";
  const v = ctx.createLinearGradient(0, 0, 0, 128);
  v.addColorStop(0, "rgba(0,0,0,1)");
  v.addColorStop(1, "rgba(0,0,0,0)");
  ctx.fillStyle = v;
  ctx.fillRect(0, 0, 128, 128);
}

function paintBubble(ctx) {
  blob(ctx, 64, 64, 50, 50, "rgba(255,255,255,0.15)", "rgba(255,255,255,0.9)", 12);
  blob(ctx, 44, 42, 14, 14, "rgba(255,255,255,0.9)", null);
}

function paintWeed(ctx) {
  blob(ctx, 64, 64, 34, 60, "#2f9e44", "#1b5e2a", 10);
}

// All swimmers face left; `alt` picks the second animation pose.
function paintFish([body, stripe], alt) {
  return (ctx) => {
    const bend = alt ? -9 : 9;
    ctx.fillStyle = body;
    ctx.strokeStyle = "#222";
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(88, 64);
    ctx.lineTo(124, 38 + bend);
    ctx.lineTo(116, 64 + bend * 0.5);
    ctx.lineTo(124, 90 + bend);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(44, 46);
    ctx.quadraticCurveTo(66, 18, 84, 48);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    ctx.save();
    blob(ctx, 58, 64, 38, 24, body);
    ctx.clip();
    ctx.fillStyle = stripe;
    ctx.fillRect(50, 30, 10, 70);
    ctx.fillRect(72, 30, 9, 70);
    ctx.restore();
    blob(ctx, 58, 64, 38, 24, null);
    eye(ctx, 36, 58);
  };
}

function paintPuffer(alt) {
  return (ctx) => {
    const r = alt ? 40 : 34; // puffs in and out
    ctx.fillStyle = "#e6c34a";
    ctx.beginPath();
    ctx.moveTo(98, 64);
    ctx.lineTo(122, 48);
    ctx.lineTo(122, 80);
    ctx.fill();
    ctx.strokeStyle = "#6b5212";
    ctx.lineWidth = 5;
    for (let a = 0; a < Math.PI * 2; a += Math.PI / 7) {
      ctx.beginPath();
      ctx.moveTo(60 + Math.cos(a) * r, 64 + Math.sin(a) * r);
      ctx.lineTo(60 + Math.cos(a) * (r + 12), 64 + Math.sin(a) * (r + 12));
      ctx.stroke();
    }
    blob(ctx, 60, 64, r, r, "#f2d65c", "#6b5212", 4);
    blob(ctx, 60, 78, r * 0.7, r * 0.4, "#fff6c8", null);
    for (const [x, y] of [[54, 46], [72, 54], [64, 40]]) blob(ctx, x, y, 4, 4, "#8a6a14", null);
    eye(ctx, 38, 56, 9);
  };
}

function paintAngel(alt) {
  return (ctx) => {
    const sway = alt ? 6 : -6;
    ctx.fillStyle = "#c9d4ff";
    ctx.strokeStyle = "#222";
    ctx.lineWidth = 3;
    // Tall fins up and down
    ctx.beginPath();
    ctx.moveTo(40, 64);
    ctx.lineTo(80 + sway, 4);
    ctx.lineTo(96, 64);
    ctx.lineTo(80 - sway, 124);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    ctx.save();
    blob(ctx, 62, 64, 30, 26, "#e8ecff");
    ctx.clip();
    ctx.fillStyle = "#1c1c3a";
    ctx.fillRect(52, 20, 8, 90);
    ctx.fillRect(72, 20, 8, 90);
    ctx.restore();
    blob(ctx, 62, 64, 30, 26, null);
    ctx.beginPath();
    ctx.moveTo(92, 64);
    ctx.lineTo(118, 48 + sway);
    ctx.lineTo(118, 80 + sway);
    ctx.closePath();
    ctx.fillStyle = "#c9d4ff";
    ctx.fill();
    ctx.stroke();
    eye(ctx, 42, 58, 6);
  };
}

function paintJelly(alt) {
  return (ctx) => {
    const squish = alt ? 6 : 0;
    ctx.strokeStyle = "rgba(255,170,230,0.9)";
    ctx.lineWidth = 6;
    for (let i = 0; i < 5; i++) {
      const x = 36 + i * 14;
      ctx.beginPath();
      ctx.moveTo(x, 60);
      ctx.bezierCurveTo(x + 10, 80, x - 10, 100, x + (alt ? 6 : -6), 124);
      ctx.stroke();
    }
    ctx.beginPath();
    ctx.ellipse(64, 56 + squish / 2, 44 + squish, 36 - squish, 0, Math.PI, 0);
    ctx.closePath();
    ctx.fillStyle = "rgba(255,120,210,0.75)";
    ctx.fill();
    ctx.lineWidth = 4;
    ctx.strokeStyle = "#ffd6f2";
    ctx.stroke();
  };
}

function paintCrab(alt) {
  return (ctx) => {
    ctx.strokeStyle = "#8c1d10";
    ctx.lineWidth = 7;
    for (let i = 0; i < 3; i++) {
      const lift = (i % 2 === 0) === alt ? -8 : 0;
      for (const s of [-1, 1]) {
        ctx.beginPath();
        ctx.moveTo(64 + s * 20, 80);
        ctx.lineTo(64 + s * (38 + i * 8), 90 + lift);
        ctx.lineTo(64 + s * (44 + i * 8), 112 + lift);
        ctx.stroke();
      }
    }
    for (const s of [-1, 1]) {
      ctx.beginPath();
      ctx.moveTo(64 + s * 24, 64);
      ctx.lineTo(64 + s * 42, 44);
      ctx.stroke();
      blob(ctx, 64 + s * 46, 34 + (alt ? -4 : 0), 14, 11, "#e2422b", "#8c1d10", 4);
    }
    blob(ctx, 64, 76, 34, 22, "#e2422b", "#8c1d10", 4);
    for (const s of [-1, 1]) {
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.moveTo(64 + s * 8, 58);
      ctx.lineTo(64 + s * 10, 44);
      ctx.stroke();
      blob(ctx, 64 + s * 10, 42, 6, 6, "#fff", null);
      blob(ctx, 64 + s * 10, 42, 3, 3, "#000", null);
    }
  };
}

function paintSeahorse(ctx) {
  ctx.fillStyle = "#ff9f1c";
  ctx.strokeStyle = "#7a3e00";
  ctx.lineWidth = 4;
  ctx.beginPath();
  ctx.moveTo(56, 20);           // top of head
  ctx.quadraticCurveTo(84, 16, 80, 44);
  ctx.quadraticCurveTo(92, 72, 74, 92);
  ctx.quadraticCurveTo(64, 110, 76, 118); // curled tail
  ctx.quadraticCurveTo(52, 118, 58, 96);
  ctx.quadraticCurveTo(48, 70, 58, 46);
  ctx.lineTo(30, 40);           // snout
  ctx.lineTo(30, 30);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();
  blob(ctx, 88, 62, 8, 14, "#ffd08a", "#7a3e00", 3); // back fin
  eye(ctx, 60, 30, 6);
}

function paintStar(ctx) {
  ctx.beginPath();
  for (let i = 0; i < 10; i++) {
    const a = -Math.PI / 2 + (i * Math.PI) / 5;
    const r = i % 2 ? 22 : 56;
    ctx.lineTo(64 + Math.cos(a) * r, 70 + Math.sin(a) * r);
  }
  ctx.closePath();
  ctx.fillStyle = "#ff6b6b";
  ctx.fill();
  ctx.lineWidth = 4;
  ctx.strokeStyle = "#8a1f1f";
  ctx.stroke();
  for (const [x, y] of [[64, 60], [50, 76], [78, 76]]) blob(ctx, x, y, 4, 4, "#ffd0d0", null);
}

// Big rare visitors are drawn 2:1 (sprite w = 2h), so painters work in a
// 128x64 space stretched to fill the square cell.
function paintShark(alt) {
  return (ctx) => {
    ctx.scale(1, 2);
    const flick = alt ? -5 : 5;
    ctx.strokeStyle = "#1f2a33";
    ctx.lineWidth = 2;
    ctx.fillStyle = "#7d8f9c";
    // Tail
    ctx.beginPath();
    ctx.moveTo(100, 32);
    ctx.lineTo(126, 8 + flick);
    ctx.lineTo(116, 32);
    ctx.lineTo(124, 54 + flick);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    // Dorsal + pectoral fins
    ctx.beginPath();
    ctx.moveTo(52, 22);
    ctx.lineTo(66, 2);
    ctx.lineTo(74, 22);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(44, 40);
    ctx.lineTo(60, 58);
    ctx.lineTo(62, 40);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    // Torpedo body with a pale belly
    ctx.beginPath();
    ctx.moveTo(4, 32);
    ctx.quadraticCurveTo(30, 14, 70, 20);
    ctx.quadraticCurveTo(96, 24, 104, 32);
    ctx.quadraticCurveTo(80, 44, 40, 42);
    ctx.quadraticCurveTo(14, 40, 4, 32);
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = "#e6ecef";
    ctx.beginPath();
    ctx.moveTo(10, 35);
    ctx.quadraticCurveTo(40, 44, 90, 35);
    ctx.quadraticCurveTo(50, 40, 10, 35);
    ctx.fill();
    // Gills, toothy grin, mean little eye
    ctx.beginPath();
    for (const x of [30, 34, 38]) { ctx.moveTo(x, 27); ctx.lineTo(x - 2, 35); }
    ctx.stroke();
    ctx.strokeStyle = "#fff";
    ctx.beginPath();
    ctx.moveTo(8, 35);
    for (let x = 8; x < 22; x += 3) ctx.lineTo(x + 1.5, x % 2 ? 37 : 35);
    ctx.stroke();
    blob(ctx, 18, 28, 2.5, 2.5, "#000", null);
  };
}

function paintWhale(alt) {
  return (ctx) => {
    ctx.scale(1, 2);
    const fluke = alt ? -6 : 6;
    ctx.strokeStyle = "#0e2440";
    ctx.lineWidth = 2;
    ctx.fillStyle = "#3d6c9e";
    // Tail flukes
    ctx.beginPath();
    ctx.moveTo(98, 30);
    ctx.quadraticCurveTo(112, 26, 118, 12 + fluke);
    ctx.lineTo(126, 22 + fluke);
    ctx.quadraticCurveTo(116, 30, 126, 40 + fluke);
    ctx.lineTo(118, 48 + fluke);
    ctx.quadraticCurveTo(112, 36, 98, 36);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    // Big round body
    ctx.beginPath();
    ctx.moveTo(6, 34);
    ctx.quadraticCurveTo(8, 10, 44, 12);
    ctx.quadraticCurveTo(84, 14, 102, 32);
    ctx.quadraticCurveTo(80, 52, 40, 52);
    ctx.quadraticCurveTo(6, 52, 6, 34);
    ctx.fill();
    ctx.stroke();
    // Striped throat
    ctx.fillStyle = "#c9dff0";
    ctx.beginPath();
    ctx.moveTo(8, 40);
    ctx.quadraticCurveTo(30, 54, 70, 46);
    ctx.quadraticCurveTo(36, 46, 8, 40);
    ctx.fill();
    ctx.strokeStyle = "#7fa6c8";
    ctx.beginPath();
    for (const y of [43, 46]) { ctx.moveTo(14, y); ctx.lineTo(56, y + 2); }
    ctx.stroke();
    // Flipper and eye
    ctx.fillStyle = "#2f5885";
    ctx.beginPath();
    ctx.ellipse(44, 46, 10, 4, 0.5, 0, Math.PI * 2);
    ctx.fill();
    blob(ctx, 22, 34, 2.5, 2.5, "#000", null);
  };
}

// Atlas layout: each entry is [name, painter] so indexes are looked up by name.
const ENTRIES = [
  ["water", paintWater], ["sand", paintSand], ["ray", paintRay],
  ["bubble", paintBubble], ["weed", paintWeed],
  ...FISH_COLORS.flatMap((c, n) => [[`fish${n}a`, paintFish(c, false)], [`fish${n}b`, paintFish(c, true)]]),
  ["puffa", paintPuffer(false)], ["puffb", paintPuffer(true)],
  ["angela", paintAngel(false)], ["angelb", paintAngel(true)],
  ["jellya", paintJelly(false)], ["jellyb", paintJelly(true)],
  ["craba", paintCrab(false)], ["crabb", paintCrab(true)],
  ["seahorse", paintSeahorse], ["star", paintStar],
  ["sharka", paintShark(false)], ["sharkb", paintShark(true)],
  ["whalea", paintWhale(false)], ["whaleb", paintWhale(true)],
];

// Rare visitors: at most one at a time, every VISIT_GAP seconds or so.
const VISITORS = [
  { frames: ["sharka", "sharkb"], size: 300, v: 90, rate: 3 },
  { frames: ["whalea", "whaleb"], size: 520, v: 35, rate: 0.8 },
];
const VISIT_GAP = [25, 60];
const IDX = Object.fromEntries(ENTRIES.map(([name], i) => [name, i]));

// Horizontal swimmers: frames, size range, speed range, animation rate.
const SWIMMERS = [
  ...FISH_COLORS.map((_, n) => ({ frames: [`fish${n}a`, `fish${n}b`], size: [50, 110], v: [30, 80], rate: 5 })),
  { frames: ["puffa", "puffb"], size: [50, 80], v: [15, 30], rate: 1.2 },
  { frames: ["angela", "angelb"], size: [70, 110], v: [20, 40], rate: 2 },
];

const H = 600;
const rand = (a, b) => a + Math.random() * (b - a);

export default {
  id: "fishbowl",
  name: "Fishbowl",
  blurb: "Ur very own aquarium. Now with CRABS. Glub glub.",
  create(canvas, opts) {
    const gl = getGL(canvas);
    const batch = createSpriteBatch(gl, ENTRIES.map(([, p]) => p));
    let W = H * (canvas.clientWidth / canvas.clientHeight || 1.5);

    const newSwimmer = (o, anywhere) => {
      o.kind = SWIMMERS[Math.floor(Math.random() * SWIMMERS.length)];
      o.size = rand(...o.kind.size);
      o.dir = Math.random() < 0.5 ? -1 : 1;
      o.v = rand(...o.kind.v);
      o.baseY = rand(60, H - 160);
      o.phase = Math.random() * 6;
      o.x = anywhere ? Math.random() * W : o.dir > 0 ? -o.size : W + o.size;
      return o;
    };
    const swimmers = Array.from({ length: 11 }, () => newSwimmer({}, true));

    const jellies = Array.from({ length: 3 }, () => ({
      fx: Math.random(), y: rand(80, H - 200), size: rand(50, 90), phase: Math.random() * 6,
    }));
    const horses = Array.from({ length: 2 }, () => ({
      x: rand(0, 1), size: rand(60, 85), dir: Math.random() < 0.5 ? -1 : 1, phase: Math.random() * 6, y: rand(150, H - 180),
    }));
    const crabs = Array.from({ length: 2 }, () => ({
      x: rand(0, 1), size: rand(45, 65), dir: Math.random() < 0.5 ? -1 : 1, pause: 0,
    }));
    const stars = Array.from({ length: 3 }, () => ({ fx: Math.random(), size: rand(28, 42), dy: rand(0, 25) }));

    const newBubble = (b, anywhere) => {
      b.x = Math.random() * W;
      b.y = anywhere ? Math.random() * H : H + 10;
      b.r = rand(5, 17);
      b.v = rand(40, 100);
      b.phase = Math.random() * 6;
      return b;
    };
    const bubbles = Array.from({ length: 30 }, () => newBubble({}, true));
    const weeds = Array.from({ length: 7 }, (_, i) => ({ fx: (i + 0.5) / 7 + rand(-0.04, 0.04), len: 8 + Math.floor(Math.random() * 8) }));

    let visitor = null;
    // Cheat code: ?visit summons the first visitor right away.
    let nextVisit = new URLSearchParams(location.search).has("visit") ? 1 : rand(...VISIT_GAP);

    let t = 0;
    return runLoop(gl, (dt) => {
      W = H * (gl.canvas.width / gl.canvas.height);
      const step = dt * (opts?.speed ?? 1);
      t += step;
      const frame = (rate, phase) => Math.floor(t * rate + phase) % 2;

      if (!visitor && (nextVisit -= step) <= 0) {
        const kind = VISITORS[Math.floor(Math.random() * VISITORS.length)];
        const dir = Math.random() < 0.5 ? -1 : 1;
        visitor = { kind, dir, x: dir > 0 ? -kind.size : W + kind.size, y: rand(H * 0.25, H * 0.6) };
      }
      if (visitor) {
        visitor.x += visitor.dir * visitor.kind.v * step;
        if (visitor.x < -visitor.kind.size * 1.2 || visitor.x > W + visitor.kind.size * 1.2) {
          visitor = null;
          nextVisit = rand(...VISIT_GAP);
        }
      }

      const back = [{ i: IDX.water, x: W / 2, y: H / 2, w: W, h: H }];
      for (let r = 0; r < 4; r++) {
        back.push({
          i: IDX.ray, x: ((r + 0.5) / 4) * W + Math.sin(t * 0.2 + r) * 60, y: H * 0.45,
          w: 140, h: H * 0.95, alpha: 0.07 + 0.05 * Math.sin(t * 0.9 + r * 2),
        });
      }
      back.push({ i: IDX.sand, x: W / 2, y: H - 45, w: W, h: 110 });
      for (const s of stars) back.push({ i: IDX.star, x: s.fx * W, y: H - 30 - s.dy, w: s.size, h: s.size });

      const weedSprites = (parity) => {
        const out = [];
        weeds.forEach((wd, n) => {
          if (n % 2 !== parity) return;
          for (let k = 0; k < wd.len; k++) {
            out.push({
              i: IDX.weed, w: 22, h: 34,
              x: wd.fx * W + Math.sin(t * 1.3 + k * 0.4 + n) * k * 1.8,
              y: H - 40 - k * 22,
            });
          }
        });
        return out;
      };

      for (const c of crabs) {
        if (c.pause > 0) c.pause -= step;
        else {
          c.x += (c.dir * 40 * step) / W;
          if (c.x < 0.05 || c.x > 0.95) c.dir *= -1;
          if (Math.random() < step * 0.4) c.pause = rand(0.5, 2);
        }
      }
      const crabSprites = crabs.map((c) => ({
        i: c.pause > 0 ? IDX.craba : IDX.craba + frame(8, 0),
        x: c.x * W, y: H - 35, w: c.size, h: c.size,
      }));

      for (const f of swimmers) {
        f.x += f.dir * f.v * step;
        if (f.x < -f.size * 1.5 || f.x > W + f.size * 1.5) newSwimmer(f, false);
      }
      for (const h of horses) {
        h.x += (h.dir * 12 * step) / W;
        if (h.x < 0.05 || h.x > 0.95) h.dir *= -1;
      }
      const middle = [
        ...swimmers.map((f) => ({
          size: f.size,
          i: IDX[f.kind.frames[frame(f.kind.rate, f.phase)]],
          x: f.x, y: f.baseY + Math.sin(t * 0.8 + f.phase) * 12,
          w: f.size, h: f.size, flip: f.dir > 0,
        })),
        ...horses.map((h) => ({
          size: h.size, i: IDX.seahorse, x: h.x * W, y: h.y + Math.sin(t * 1.5 + h.phase) * 20,
          w: h.size * 0.7, h: h.size, flip: h.dir > 0,
        })),
        ...jellies.map((j) => {
          // Pulse up, sink slowly; wrap from the top back to the bottom.
          const pulse = frame(1.5, j.phase);
          j.y -= (pulse ? 35 : -8) * step;
          if (j.y < -j.size) j.y = H;
          return {
            size: j.size, i: IDX.jellya + pulse, x: j.fx * W + Math.sin(t * 0.4 + j.phase) * 30,
            y: j.y, w: j.size, h: j.size, alpha: 0.85,
          };
        }),
        ...(visitor ? [{
          size: visitor.kind.size, i: IDX[visitor.kind.frames[frame(visitor.kind.rate, 0)]],
          x: visitor.x, y: visitor.y + Math.sin(t * 0.5) * 10,
          w: visitor.kind.size, h: visitor.kind.size / 2, flip: visitor.dir > 0,
        }] : []),
      ].sort((a, b) => a.size - b.size);

      for (const b of bubbles) {
        b.y -= b.v * step;
        if (b.y < -20) newBubble(b, false);
      }
      const bubbleSprites = bubbles.map((b) => ({
        i: IDX.bubble, x: b.x + Math.sin(t * 2 + b.phase) * 6, y: b.y, w: b.r * 2, h: b.r * 2, alpha: 0.8,
      }));

      gl.clearColor(0, 0, 0, 1);
      gl.clear(gl.COLOR_BUFFER_BIT);
      batch.draw([...back, ...weedSprites(0), ...crabSprites, ...middle, ...weedSprites(1), ...bubbleSprites], W, H);
    });
  },
};
