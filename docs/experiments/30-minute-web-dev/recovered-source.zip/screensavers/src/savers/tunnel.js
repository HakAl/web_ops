// Endless checkerboard tunnel, the classic "flying thru the wormhole" saver.
import { fragmentSaver } from "../gl.js";

export default {
  id: "tunnel",
  name: "Cyber Tunnel 2000",
  blurb: "Enter the CYBERSPACE. Y2K compliant.",
  create: fragmentSaver(`
    precision mediump float;
    uniform float uTime;
    uniform vec2 uRes;
    void main() {
      vec2 p = (gl_FragCoord.xy - 0.5 * uRes) / uRes.y;
      p += 0.15 * vec2(sin(uTime * 0.7), cos(uTime * 0.5));
      float r = length(p);
      float a = atan(p.y, p.x) / 6.28318;
      vec2 tuv = vec2(a * 8.0 + uTime * 0.2, 0.4 / r + uTime * 1.5);
      vec2 cell = floor(tuv);
      float check = mod(cell.x + cell.y, 2.0);
      vec3 c1 = vec3(0.0, 1.0, 0.8);
      vec3 c2 = vec3(0.6, 0.0, 1.0);
      vec3 col = mix(c1, c2, check) * smoothstep(0.0, 0.6, r);
      gl_FragColor = vec4(col, 1.0);
    }`),
};
