// "Mystify Your Mind": two bouncing quadrilaterals leaving echo trails.
import { getGL, createProgram, runLoop } from "../gl.js";

const VS = `
attribute vec2 aPos;
void main() { gl_Position = vec4(aPos, 0.0, 1.0); }`;

const FS = `
precision mediump float;
uniform vec4 uColor;
void main() { gl_FragColor = uColor; }`;

const ECHOES = 6;   // trail copies per polygon
const GAP = 0.045;  // seconds between trail snapshots

function makeShape() {
  const pts = [];
  for (let i = 0; i < 4; i++) {
    pts.push({
      x: Math.random() * 2 - 1,
      y: Math.random() * 2 - 1,
      vx: (Math.random() * 0.6 + 0.3) * (Math.random() < 0.5 ? -1 : 1),
      vy: (Math.random() * 0.6 + 0.3) * (Math.random() < 0.5 ? -1 : 1),
    });
  }
  return { pts, history: [], hue: Math.random() * 360 };
}

function hsl(h) {
  // Cheap hue -> rgb at full saturation, mid lightness.
  const f = (n) => {
    const k = (n + h / 30) % 12;
    return 0.5 - 0.5 * Math.max(-1, Math.min(k - 3, 9 - k, 1));
  };
  return [f(0), f(8), f(4)];
}

export default {
  id: "mystify",
  name: "Mystify Your Mind",
  blurb: "Hypnotic lines from the future (1995). Very relaxing.",
  create(canvas, opts) {
    const gl = getGL(canvas);
    const prog = createProgram(gl, VS, FS);
    const aPos = gl.getAttribLocation(prog, "aPos");
    const uColor = gl.getUniformLocation(prog, "uColor");
    const buf = gl.createBuffer();
    const shapes = [makeShape(), makeShape()];
    let acc = 0;

    return runLoop(gl, (dt) => {
      const speed = opts?.speed ?? 1;
      const step = dt * speed;
      acc += step;
      const snap = acc >= GAP;
      if (snap) acc = 0;

      for (const s of shapes) {
        for (const p of s.pts) {
          p.x += p.vx * step;
          p.y += p.vy * step;
          if (p.x < -1 || p.x > 1) { p.vx *= -1; p.x = Math.max(-1, Math.min(1, p.x)); }
          if (p.y < -1 || p.y > 1) { p.vy *= -1; p.y = Math.max(-1, Math.min(1, p.y)); }
        }
        s.hue = (s.hue + step * 20) % 360;
        if (snap) {
          s.history.unshift(s.pts.flatMap((p) => [p.x, p.y]));
          s.history.length = Math.min(s.history.length, ECHOES);
        }
      }

      gl.clearColor(0, 0, 0, 1);
      gl.clear(gl.COLOR_BUFFER_BIT);
      gl.useProgram(prog);
      gl.bindBuffer(gl.ARRAY_BUFFER, buf);
      gl.enableVertexAttribArray(aPos);
      gl.vertexAttribPointer(aPos, 2, gl.FLOAT, false, 0, 0);

      for (const s of shapes) {
        const [r, g, b] = hsl(s.hue);
        s.history.forEach((verts, i) => {
          const fade = 1 - i / ECHOES;
          gl.uniform4f(uColor, r * fade, g * fade, b * fade, 1);
          gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(verts), gl.DYNAMIC_DRAW);
          gl.drawArrays(gl.LINE_LOOP, 0, 4);
        });
      }
    });
  },
};
