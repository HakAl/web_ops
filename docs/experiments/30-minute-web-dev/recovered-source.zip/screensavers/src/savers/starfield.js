// "Starfield Simulation": stars (asteroids, if you squint) rushing at the screen.
// Each star is drawn as a streak from its current depth back along its path.
import { getGL, createProgram, runLoop } from "../gl.js";

const VS = `
attribute vec3 aPos;
uniform float uAspect;
varying float vBright;
void main() {
  vec2 p = aPos.xy / aPos.z;
  p.x /= uAspect;
  gl_Position = vec4(p, 0.0, 1.0);
  float b = clamp(1.0 - aPos.z / 4.0, 0.0, 1.0);
  vBright = b;
  gl_PointSize = 1.0 + b * b * 7.0;
}`;

// Far stars are dim and bluish, near ones bright white. uRound is set while
// drawing points so the heads are discs rather than squares.
const FS = `
precision mediump float;
uniform float uRound;
varying float vBright;
void main() {
  if (uRound > 0.5 && length(gl_PointCoord - 0.5) > 0.5) discard;
  vec3 tint = mix(vec3(0.55, 0.65, 1.0), vec3(1.0), vBright);
  gl_FragColor = vec4(tint * vBright, 1.0);
}`;

const COUNT = 600;
const FAR = 4.0;
const NEAR = 0.05;

export default {
  id: "starfield",
  name: "Starfield Simulation",
  blurb: "Warp speed thru the void!!! Do NOT stare 4 too long.",
  create(canvas, opts) {
    const gl = getGL(canvas);
    const prog = createProgram(gl, VS, FS);
    const aPos = gl.getAttribLocation(prog, "aPos");
    const uAspect = gl.getUniformLocation(prog, "uAspect");
    const uRound = gl.getUniformLocation(prog, "uRound");

    const stars = new Float32Array(COUNT * 3);
    const spawn = (i, z) => {
      stars[i * 3] = (Math.random() * 2 - 1) * 1.5;
      stars[i * 3 + 1] = (Math.random() * 2 - 1) * 1.5;
      stars[i * 3 + 2] = z;
    };
    for (let i = 0; i < COUNT; i++) spawn(i, NEAR + Math.random() * (FAR - NEAR));

    // Two vertices per star for the streak (head, tail); heads also drawn as points.
    const lineVerts = new Float32Array(COUNT * 6);
    const buf = gl.createBuffer();

    return runLoop(gl, (dt) => {
      const speed = 1.2 * (opts?.speed ?? 1);
      for (let i = 0; i < COUNT; i++) {
        const k = i * 3;
        stars[k + 2] -= speed * dt;
        const z = stars[k + 2];
        if (z < NEAR || Math.abs(stars[k] / z) > 3 || Math.abs(stars[k + 1] / z) > 2) {
          spawn(i, FAR);
        }
        const o = i * 6;
        lineVerts[o] = stars[k];
        lineVerts[o + 1] = stars[k + 1];
        lineVerts[o + 2] = stars[k + 2];
        lineVerts[o + 3] = stars[k];
        lineVerts[o + 4] = stars[k + 1];
        lineVerts[o + 5] = Math.min(FAR, stars[k + 2] + speed * 0.06);
      }

      gl.clearColor(0, 0, 0, 1);
      gl.clear(gl.COLOR_BUFFER_BIT);
      gl.useProgram(prog);
      gl.uniform1f(uAspect, gl.canvas.width / gl.canvas.height);
      gl.bindBuffer(gl.ARRAY_BUFFER, buf);
      gl.bufferData(gl.ARRAY_BUFFER, lineVerts, gl.DYNAMIC_DRAW);
      gl.enableVertexAttribArray(aPos);

      gl.vertexAttribPointer(aPos, 3, gl.FLOAT, false, 0, 0);
      gl.uniform1f(uRound, 0);
      gl.drawArrays(gl.LINES, 0, COUNT * 2);
      // Heads only: stride over the tail vertex.
      gl.vertexAttribPointer(aPos, 3, gl.FLOAT, false, 24, 0);
      gl.uniform1f(uRound, 1);
      gl.drawArrays(gl.POINTS, 0, COUNT);
    });
  },
};
