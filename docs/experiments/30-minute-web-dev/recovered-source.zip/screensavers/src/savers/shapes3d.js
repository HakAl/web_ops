// "3D Shapes": wireframe solids tumbling and bouncing around a perspective box.
import { getGL, createProgram, runLoop } from "../gl.js";

const VS = `
attribute vec3 aPos;
uniform mat3 uRot;
uniform vec3 uOffset;
uniform float uAspect;
void main() {
  vec3 p = uRot * aPos + uOffset;
  p.z += 4.0;
  gl_Position = vec4(p.x / uAspect, p.y, 0.0, p.z * 0.5);
}`;

const FS = `
precision mediump float;
uniform vec3 uColor;
void main() { gl_FragColor = vec4(uColor, 1.0); }`;

// Edge lists as flat [x,y,z, x,y,z, ...] line pairs.
function cube() {
  const v = [];
  for (let i = 0; i < 8; i++) v.push([(i & 1) * 2 - 1, (i >> 1 & 1) * 2 - 1, (i >> 2 & 1) * 2 - 1]);
  const out = [];
  for (let a = 0; a < 8; a++) for (let b = a + 1; b < 8; b++) {
    const diff = a ^ b;
    if (diff === 1 || diff === 2 || diff === 4) out.push(...v[a], ...v[b]);
  }
  return out.map((n) => n * 0.5);
}

function octahedron() {
  const v = [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]];
  const out = [];
  for (let a = 0; a < 6; a++) for (let b = a + 1; b < 6; b++) {
    if (Math.floor(a / 2) !== Math.floor(b / 2)) out.push(...v[a], ...v[b]);
  }
  return out.map((n) => n * 0.7);
}

function rotation(ax, ay, az) {
  const [cx, sx, cy, sy, cz, sz] = [Math.cos(ax), Math.sin(ax), Math.cos(ay), Math.sin(ay), Math.cos(az), Math.sin(az)];
  // Column-major Rz * Ry * Rx
  return new Float32Array([
    cz * cy, sz * cy, -sy,
    cz * sy * sx - sz * cx, sz * sy * sx + cz * cx, cy * sx,
    cz * sy * cx + sz * sx, sz * sy * cx - cz * sx, cy * cx,
  ]);
}

export default {
  id: "shapes3d",
  name: "3D Shapes",
  blurb: "REAL 3D graphix!!! Get a Voodoo card 4 best results.",
  create(canvas, opts) {
    const gl = getGL(canvas);
    const prog = createProgram(gl, VS, FS);
    const aPos = gl.getAttribLocation(prog, "aPos");
    const u = (n) => gl.getUniformLocation(prog, n);
    const [uRot, uOffset, uAspect, uColor] = ["uRot", "uOffset", "uAspect", "uColor"].map(u);

    const objs = [
      { verts: cube(), color: [1, 1, 0] },
      { verts: octahedron(), color: [0, 1, 1] },
      { verts: cube(), color: [1, 0, 1] },
    ].map((o) => {
      const buf = gl.createBuffer();
      gl.bindBuffer(gl.ARRAY_BUFFER, buf);
      gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(o.verts), gl.STATIC_DRAW);
      return {
        ...o, buf, count: o.verts.length / 3,
        pos: [Math.random() * 2 - 1, Math.random() * 2 - 1, Math.random() * 2 - 1],
        vel: [Math.random() - 0.5, Math.random() - 0.5, Math.random() - 0.5].map((n) => n * 2),
        rot: [0, 0, 0],
        spin: [Math.random() + 0.3, Math.random() + 0.3, Math.random() * 0.5],
      };
    });
    const bounds = [2.2, 1.6, 1.5];

    return runLoop(gl, (dt) => {
      const step = dt * (opts?.speed ?? 1);
      gl.clearColor(0, 0, 0.1, 1);
      gl.clear(gl.COLOR_BUFFER_BIT);
      gl.useProgram(prog);
      gl.uniform1f(uAspect, gl.canvas.width / gl.canvas.height);
      for (const o of objs) {
        for (let k = 0; k < 3; k++) {
          o.pos[k] += o.vel[k] * step;
          if (Math.abs(o.pos[k]) > bounds[k]) { o.vel[k] *= -1; o.pos[k] = Math.sign(o.pos[k]) * bounds[k]; }
          o.rot[k] += o.spin[k] * step;
        }
        gl.uniformMatrix3fv(uRot, false, rotation(...o.rot));
        gl.uniform3fv(uOffset, o.pos);
        gl.uniform3fv(uColor, o.color);
        gl.bindBuffer(gl.ARRAY_BUFFER, o.buf);
        gl.enableVertexAttribArray(aPos);
        gl.vertexAttribPointer(aPos, 3, gl.FLOAT, false, 0, 0);
        gl.drawArrays(gl.LINES, 0, o.count);
      }
    });
  },
};
