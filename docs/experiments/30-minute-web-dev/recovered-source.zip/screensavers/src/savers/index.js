import starfield from "./starfield.js";
import toasters from "./toasters.js";
import fishbowl from "./fishbowl.js";
import pipes from "./pipes.js";
import mystify from "./mystify.js";
import plasma from "./plasma.js";
import tunnel from "./tunnel.js";
import beziers from "./beziers.js";
import shapes3d from "./shapes3d.js";

export const savers = [starfield, toasters, fishbowl, pipes, mystify, plasma, tunnel, beziers, shapes3d];

export const byId = (id) => savers.find((s) => s.id === id);
