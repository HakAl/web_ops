// Fake "background MIDI": an original chiptune loop played with WebAudio.
// Browsers block autoplay, so it starts from a button, like a real 1998 site
// should have (but never did).

const _ = null;
// Lead line in eighth notes, MIDI note numbers (72 = C5).
const LEAD = [
  76, 79, 84, 79, 76, 79, 81, 79,
  77, 81, 84, 81, 79, 76, 72, 74,
  76, 79, 84, 79, 76, 79, 81, 83,
  84, 83, 81, 79, 77, 76, 74, _,
  81, 81, 79, 77, 76, 77, 79, _,
  77, 77, 76, 74, 72, 74, 76, _,
  74, 76, 77, 79, 81, 83, 84, 86,
  84, _, 79, _, 76, _, 72, _,
];
// One bass root per bar, played as bouncing quarter-note octaves.
const BASS = [48, 53, 48, 55, 57, 53, 50, 48];
const BPM = 150;
const EIGHTH = 60 / BPM / 2;

const freq = (n) => 440 * 2 ** ((n - 69) / 12);

let audio = null;
let timer = null;
let step = 0;
let nextTime = 0;

function note(type, n, at, len, vol) {
  const osc = audio.createOscillator();
  const gain = audio.createGain();
  osc.type = type;
  osc.frequency.value = freq(n);
  gain.gain.setValueAtTime(vol, at);
  gain.gain.exponentialRampToValueAtTime(0.001, at + len);
  osc.connect(gain).connect(audio.destination);
  osc.start(at);
  osc.stop(at + len);
}

function hat(at) {
  const len = 0.04;
  const buf = audio.createBuffer(1, Math.floor(audio.sampleRate * len), audio.sampleRate);
  const data = buf.getChannelData(0);
  for (let i = 0; i < data.length; i++) data[i] = Math.random() * 2 - 1;
  const src = audio.createBufferSource();
  const gain = audio.createGain();
  gain.gain.setValueAtTime(0.04, at);
  gain.gain.exponentialRampToValueAtTime(0.001, at + len);
  src.buffer = buf;
  src.connect(gain).connect(audio.destination);
  src.start(at);
}

// Look-ahead scheduler: queue notes slightly ahead of the audio clock.
function schedule() {
  while (nextTime < audio.currentTime + 0.15) {
    const i = step % LEAD.length;
    if (LEAD[i] !== null) note("square", LEAD[i], nextTime, EIGHTH * 0.9, 0.06);
    if (i % 2 === 0) {
      const root = BASS[Math.floor(i / 8)];
      note("triangle", root + (i % 4 === 0 ? 0 : 12), nextTime, EIGHTH * 1.8, 0.18);
    }
    hat(nextTime);
    nextTime += EIGHTH;
    step++;
  }
}

export function setupMidi() {
  const btn = document.getElementById("midi");
  const label = document.getElementById("midi-label");
  btn.onclick = () => {
    if (timer) {
      clearInterval(timer);
      timer = null;
      audio.suspend();
      btn.textContent = "♫ MIDI: OFF";
      label.textContent = "";
      return;
    }
    audio ??= new AudioContext();
    audio.resume();
    step = 0;
    nextTime = audio.currentTime + 0.05;
    timer = setInterval(schedule, 25);
    btn.textContent = "♫ MIDI: ON";
    label.textContent = "Now playing: daves_theme.mid";
  };
}
