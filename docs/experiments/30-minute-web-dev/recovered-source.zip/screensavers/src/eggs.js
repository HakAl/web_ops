// Easter eggs!
//  1. Konami code (up up down down left right left right b a) -> RAD MODE
//  2. Click the UNDER CONSTRUCTION sign -> Pong
//  3. Click the visitor counter -> falling blocks
import { startPong, W as PONG_W, H as PONG_H } from "./games/pong.js";
import { startTetris, W as TET_W, H as TET_H } from "./games/tetris.js";

// ---------- Game window ----------

let closeGame = null;

function openGame(title, start, w, h, help) {
  closeGame?.();
  const win = document.createElement("div");
  win.className = "win95 game-win";
  win.innerHTML = `
    <div class="titlebar"><span>${title}</span><button class="x bevel" title="close">x</button></div>
    <div class="win-body">
      <canvas class="game-canvas" style="width:${w * 2}px;height:${h * 2}px"></canvas>
      <p class="game-help">${help}</p>
    </div>`;
  document.body.appendChild(win);
  const canvas = win.querySelector("canvas");
  const stop = start(canvas);
  const onEsc = (e) => e.key === "Escape" && closeGame();
  closeGame = () => {
    stop();
    win.remove();
    removeEventListener("keydown", onEsc);
    closeGame = null;
  };
  win.querySelector(".x").onclick = () => closeGame();
  addEventListener("keydown", onEsc);
  canvas.focus();
}

export function setupEggs() {
  const sign = document.querySelector(".construction");
  sign.title = "do NOT click this";
  sign.onclick = () => openGame("PONG.EXE", startPong, PONG_W, PONG_H,
    "W/S or arrows or mouse to move. First to 7 wins. Esc to quit.");

  const counter = document.querySelector(".counter-box");
  counter.title = "insert coin";
  counter.onclick = () => openGame("BLOCKS.EXE", startTetris, TET_W, TET_H,
    "Left/Right move, Up rotate, Down soft drop, Space hard drop. Esc to quit.");

  setupKonami();
}

// ---------- Konami code -> RAD MODE ----------

const CODE = ["ArrowUp", "ArrowUp", "ArrowDown", "ArrowDown", "ArrowLeft", "ArrowRight", "ArrowLeft", "ArrowRight", "b", "a"];

function setupKonami() {
  let pos = 0;
  addEventListener("keydown", (e) => {
    if (closeGame) return; // don't trigger from inside a game
    const k = e.key.length === 1 ? e.key.toLowerCase() : e.key;
    pos = k === CODE[pos] ? pos + 1 : k === CODE[0] ? 1 : 0;
    if (pos === CODE.length) {
      pos = 0;
      toggleRad();
    }
  });
}

let sparkle = null;

function toggleRad() {
  const on = document.body.classList.toggle("rad");
  const marquee = document.querySelector(".top-marquee");
  marquee.dataset.orig ??= marquee.textContent;
  marquee.textContent = on
    ? "!!! RAD MODE ACTIVATED !!! U R 1337 !!! +30 LIVES !!! greetz 2 all my homies on the webring !!!"
    : marquee.dataset.orig;
  if (on) {
    sparkle = (e) => {
      const s = document.createElement("span");
      s.className = "sparkle";
      s.textContent = ["*", "+", "★", "✦"][Math.floor(Math.random() * 4)];
      s.style.left = e.pageX + "px";
      s.style.top = e.pageY + "px";
      s.style.color = `hsl(${Math.random() * 360},100%,60%)`;
      document.body.appendChild(s);
      setTimeout(() => s.remove(), 700);
    };
    addEventListener("mousemove", sparkle);
  } else {
    removeEventListener("mousemove", sparkle);
  }
}
