// Tiny WebGL helpers shared by every screensaver.

export function getGL(canvas) {
  const gl = canvas.getContext("webgl", { antialias: true, preserveDrawingBuffer: false });
  if (!gl) throw new Error("WebGL not available");
  return gl;
}

function compile(gl, type, src) {
  const s = gl.createShader(type);
  gl.shaderSource(s, src);
  gl.compileShader(s);
  if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) {
    throw new Error(gl.getShaderInfoLog(s));
  }
  return s;
}

export function createProgram(gl, vsSrc, fsSrc) {
  const p = gl.createProgram();
  gl.attachShader(p, compile(gl, gl.VERTEX_SHADER, vsSrc));
  gl.attachShader(p, compile(gl, gl.FRAGMENT_SHADER, fsSrc));
  gl.linkProgram(p);
  if (!gl.getProgramParameter(p, gl.LINK_STATUS)) {
    throw new Error(gl.getProgramInfoLog(p));
  }
  return p;
}

export function fitCanvas(canvas) {
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  const w = Math.max(1, Math.floor(canvas.clientWidth * dpr));
  const h = Math.max(1, Math.floor(canvas.clientHeight * dpr));
  if (canvas.width !== w || canvas.height !== h) {
    canvas.width = w;
    canvas.height = h;
  }
}

// Builds a create() for screensavers that are just a fragment shader over a
// full-screen quad. The shader gets uTime (scaled by opts.speed) and uRes.
export function fragmentSaver(fsSrc) {
  return (canvas, opts) => {
    const gl = getGL(canvas);
    const prog = createProgram(gl, `
      attribute vec2 aPos;
      void main() { gl_Position = vec4(aPos, 0.0, 1.0); }`, fsSrc);
    const buf = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, buf);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]), gl.STATIC_DRAW);
    const aPos = gl.getAttribLocation(prog, "aPos");
    const uTime = gl.getUniformLocation(prog, "uTime");
    const uRes = gl.getUniformLocation(prog, "uRes");
    let t = 0;
    return runLoop(gl, (dt) => {
      t += dt * (opts?.speed ?? 1);
      gl.useProgram(prog);
      gl.bindBuffer(gl.ARRAY_BUFFER, buf);
      gl.enableVertexAttribArray(aPos);
      gl.vertexAttribPointer(aPos, 2, gl.FLOAT, false, 0, 0);
      gl.uniform1f(uTime, t);
      gl.uniform2f(uRes, gl.canvas.width, gl.canvas.height);
      gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
    });
  };
}

// Runs frame(dt, t) every animation frame while the canvas is in the page.
// Canvases are long-lived and moved around the DOM (see main.js), so a
// detached canvas just idles instead of rendering. Returns a stop function.
export function runLoop(gl, frame) {
  const canvas = gl.canvas;
  let raf;
  let last = performance.now();
  let stopped = false;
  const tick = (now) => {
    if (stopped) return;
    const dt = Math.min(0.05, (now - last) / 1000);
    last = now;
    if (canvas.isConnected) {
      fitCanvas(canvas);
      gl.viewport(0, 0, canvas.width, canvas.height);
      frame(dt, now / 1000);
    }
    raf = requestAnimationFrame(tick);
  };
  raf = requestAnimationFrame(tick);
  return () => {
    stopped = true;
    cancelAnimationFrame(raf);
  };
}
