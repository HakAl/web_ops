// Pong: you (left, W/S or arrows or mouse) vs the CPU. First to 7.
export const W = 320, H = 200;

export function startPong(canvas) {
  canvas.width = W;
  canvas.height = H;
  const ctx = canvas.getContext("2d");
  const PH = 32, PW = 4, BALL = 4, WIN = 7;
  const keys = new Set();
  let you, cpu, ball, scores, winner, raf, last = performance.now();

  const serve = (dir) => {
    const a = (Math.random() - 0.5) * 0.8;
    ball = { x: W / 2, y: H / 2, vx: Math.cos(a) * 140 * dir, vy: Math.sin(a) * 140 };
  };
  const reset = () => {
    you = H / 2;
    cpu = H / 2;
    scores = [0, 0];
    winner = null;
    serve(Math.random() < 0.5 ? -1 : 1);
  };
  reset();

  const onKey = (e) => {
    if (["ArrowUp", "ArrowDown", "w", "s", " "].includes(e.key)) e.preventDefault();
    if (e.type === "keydown") {
      keys.add(e.key);
      if (winner && (e.key === "Enter" || e.key === " ")) reset();
    } else keys.delete(e.key);
  };
  const onMouse = (e) => {
    const r = canvas.getBoundingClientRect();
    you = ((e.clientY - r.top) / r.height) * H;
  };
  addEventListener("keydown", onKey);
  addEventListener("keyup", onKey);
  canvas.addEventListener("mousemove", onMouse);

  const clampPaddle = (y) => Math.max(PH / 2, Math.min(H - PH / 2, y));

  const tick = (now) => {
    const dt = Math.min(0.03, (now - last) / 1000);
    last = now;
    if (!winner) {
      if (keys.has("ArrowUp") || keys.has("w")) you -= 200 * dt;
      if (keys.has("ArrowDown") || keys.has("s")) you += 200 * dt;
      you = clampPaddle(you);
      // CPU tracks the ball, but lazily, so it's beatable.
      const target = ball.vx > 0 ? ball.y : H / 2;
      cpu = clampPaddle(cpu + Math.sign(target - cpu) * Math.min(Math.abs(target - cpu), 115 * dt));

      ball.x += ball.vx * dt;
      ball.y += ball.vy * dt;
      if (ball.y < BALL / 2 || ball.y > H - BALL / 2) {
        ball.vy *= -1;
        ball.y = Math.max(BALL / 2, Math.min(H - BALL / 2, ball.y));
      }
      const hit = (px, py, side) => {
        if (Math.abs(ball.x - px) < PW / 2 + BALL / 2 && Math.abs(ball.y - py) < PH / 2 + BALL / 2 && Math.sign(ball.vx) === side) {
          const off = (ball.y - py) / (PH / 2); // -1..1, edges send it steeper
          const speed = Math.min(320, Math.hypot(ball.vx, ball.vy) * 1.06);
          ball.vx = -side * speed * Math.cos(off * 0.9);
          ball.vy = speed * Math.sin(off * 0.9);
        }
      };
      hit(10, you, -1);
      hit(W - 10, cpu, 1);
      if (ball.x < 0 || ball.x > W) {
        const p = ball.x < 0 ? 1 : 0;
        scores[p]++;
        if (scores[p] >= WIN) winner = p === 0 ? "U WIN!!! :D" : "CPU WINS :(";
        serve(p === 0 ? 1 : -1);
      }
    }

    ctx.fillStyle = "#000";
    ctx.fillRect(0, 0, W, H);
    ctx.fillStyle = "#0f0";
    for (let y = 4; y < H; y += 12) ctx.fillRect(W / 2 - 1, y, 2, 6);
    ctx.fillRect(10 - PW / 2, you - PH / 2, PW, PH);
    ctx.fillRect(W - 10 - PW / 2, cpu - PH / 2, PW, PH);
    if (!winner) ctx.fillRect(ball.x - BALL / 2, ball.y - BALL / 2, BALL, BALL);
    ctx.font = "16px monospace";
    ctx.textAlign = "center";
    ctx.fillText(scores[0], W / 2 - 30, 20);
    ctx.fillText(scores[1], W / 2 + 30, 20);
    if (winner) {
      ctx.fillText(winner, W / 2, H / 2);
      ctx.font = "10px monospace";
      ctx.fillText("press ENTER 4 rematch", W / 2, H / 2 + 18);
    }
    raf = requestAnimationFrame(tick);
  };
  raf = requestAnimationFrame(tick);

  return () => {
    cancelAnimationFrame(raf);
    removeEventListener("keydown", onKey);
    removeEventListener("keyup", onKey);
  };
}
