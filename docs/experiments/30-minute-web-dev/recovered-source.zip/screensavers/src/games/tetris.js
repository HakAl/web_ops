// Falling-blocks puzzle. Arrows move/rotate, Space hard-drops, P pauses.
const COLS = 10, ROWS = 20, CELL = 12;
const SIDE = 72;
export const W = COLS * CELL + SIDE, H = ROWS * CELL;

const PIECES = {
  I: { color: "#0ff", cells: [[0, 1], [1, 1], [2, 1], [3, 1]], size: 4 },
  O: { color: "#ff0", cells: [[0, 0], [1, 0], [0, 1], [1, 1]], size: 2 },
  T: { color: "#c0f", cells: [[1, 0], [0, 1], [1, 1], [2, 1]], size: 3 },
  S: { color: "#0f0", cells: [[1, 0], [2, 0], [0, 1], [1, 1]], size: 3 },
  Z: { color: "#f00", cells: [[0, 0], [1, 0], [1, 1], [2, 1]], size: 3 },
  J: { color: "#00f", cells: [[0, 0], [0, 1], [1, 1], [2, 1]], size: 3 },
  L: { color: "#f80", cells: [[2, 0], [0, 1], [1, 1], [2, 1]], size: 3 },
};
const NAMES = Object.keys(PIECES);
const LINE_SCORES = [0, 100, 300, 500, 800];

export function startTetris(canvas) {
  canvas.width = W;
  canvas.height = H;
  const ctx = canvas.getContext("2d");
  let board, piece, next, score, lines, level, over, paused, dropTimer, raf, last = performance.now();

  const newPiece = (name) => {
    const p = PIECES[name];
    return { name, color: p.color, size: p.size, cells: p.cells.map((c) => [...c]), x: 3, y: 0 };
  };
  const randomName = () => NAMES[Math.floor(Math.random() * NAMES.length)];
  const fits = (p, dx = 0, dy = 0, cells = p.cells) => cells.every(([cx, cy]) => {
    const x = p.x + cx + dx, y = p.y + cy + dy;
    return x >= 0 && x < COLS && y < ROWS && (y < 0 || !board[y][x]);
  });
  const reset = () => {
    board = Array.from({ length: ROWS }, () => Array(COLS).fill(null));
    piece = newPiece(randomName());
    next = randomName();
    score = 0;
    lines = 0;
    level = 1;
    over = false;
    paused = false;
    dropTimer = 0;
  };
  reset();

  const lock = () => {
    for (const [cx, cy] of piece.cells) {
      if (piece.y + cy < 0) { over = true; return; }
      board[piece.y + cy][piece.x + cx] = piece.color;
    }
    const kept = board.filter((row) => row.some((c) => !c));
    const cleared = ROWS - kept.length;
    while (kept.length < ROWS) kept.unshift(Array(COLS).fill(null));
    board = kept;
    lines += cleared;
    score += LINE_SCORES[cleared] * level;
    level = 1 + Math.floor(lines / 10);
    piece = newPiece(next);
    next = randomName();
    if (!fits(piece)) over = true;
  };
  const rotate = () => {
    if (piece.name === "O") return;
    const n = piece.size - 1;
    const turned = piece.cells.map(([x, y]) => [n - y, x]);
    for (const kick of [0, -1, 1, -2, 2]) { // simple wall kicks
      if (fits(piece, kick, 0, turned)) {
        piece.cells = turned;
        piece.x += kick;
        return;
      }
    }
  };
  const softDrop = () => {
    if (fits(piece, 0, 1)) piece.y++;
    else lock();
    dropTimer = 0;
  };

  const onKey = (e) => {
    if (["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight", " "].includes(e.key)) e.preventDefault();
    if (over) {
      if (e.key === "Enter") reset();
      return;
    }
    if (e.key === "p") paused = !paused;
    if (paused) return;
    if (e.key === "ArrowLeft" && fits(piece, -1)) piece.x--;
    if (e.key === "ArrowRight" && fits(piece, 1)) piece.x++;
    if (e.key === "ArrowUp") rotate();
    if (e.key === "ArrowDown") { softDrop(); score += 1; }
    if (e.key === " ") {
      while (fits(piece, 0, 1)) { piece.y++; score += 2; }
      lock();
    }
  };
  addEventListener("keydown", onKey);

  const block = (x, y, color) => {
    ctx.fillStyle = color;
    ctx.fillRect(x, y, CELL, CELL);
    ctx.fillStyle = "rgba(255,255,255,0.45)";
    ctx.fillRect(x, y, CELL, 2);
    ctx.fillRect(x, y, 2, CELL);
    ctx.fillStyle = "rgba(0,0,0,0.4)";
    ctx.fillRect(x, y + CELL - 2, CELL, 2);
    ctx.fillRect(x + CELL - 2, y, 2, CELL);
  };

  const tick = (now) => {
    const dt = Math.min(0.1, (now - last) / 1000);
    last = now;
    if (!over && !paused) {
      dropTimer += dt;
      if (dropTimer > Math.max(0.08, 0.8 - (level - 1) * 0.07)) softDrop();
    }

    ctx.fillStyle = "#000";
    ctx.fillRect(0, 0, W, H);
    ctx.fillStyle = "#111";
    ctx.fillRect(0, 0, COLS * CELL, H);
    board.forEach((row, y) => row.forEach((c, x) => c && block(x * CELL, y * CELL, c)));
    if (!over) {
      // Ghost piece shows where a hard drop would land.
      let g = 0;
      while (fits(piece, 0, g + 1)) g++;
      ctx.strokeStyle = "rgba(255,255,255,0.3)";
      for (const [cx, cy] of piece.cells) ctx.strokeRect((piece.x + cx) * CELL + 0.5, (piece.y + cy + g) * CELL + 0.5, CELL - 1, CELL - 1);
      for (const [cx, cy] of piece.cells) if (piece.y + cy >= 0) block((piece.x + cx) * CELL, (piece.y + cy) * CELL, piece.color);
    }

    const sx = COLS * CELL + 8;
    ctx.fillStyle = "#0f0";
    ctx.font = "9px monospace";
    ctx.fillText("NEXT", sx, 14);
    for (const [cx, cy] of PIECES[next].cells) block(sx + cx * CELL, 22 + cy * CELL, PIECES[next].color);
    ctx.fillStyle = "#0f0";
    ctx.fillText("SCORE", sx, 90);
    ctx.fillText(String(score), sx, 102);
    ctx.fillText("LINES", sx, 122);
    ctx.fillText(String(lines), sx, 134);
    ctx.fillText("LEVEL", sx, 154);
    ctx.fillText(String(level), sx, 166);
    ctx.fillStyle = "#888";
    ctx.fillText("P=pause", sx, 220);
    if (over || paused) {
      ctx.fillStyle = "rgba(0,0,0,0.7)";
      ctx.fillRect(0, H / 2 - 24, COLS * CELL, 44);
      ctx.fillStyle = "#ff0";
      ctx.textAlign = "center";
      ctx.font = "12px monospace";
      ctx.fillText(over ? "GAME OVER" : "PAUSED", (COLS * CELL) / 2, H / 2 - 4);
      if (over) {
        ctx.font = "9px monospace";
        ctx.fillText("ENTER = again", (COLS * CELL) / 2, H / 2 + 12);
      }
      ctx.textAlign = "left";
    }
    raf = requestAnimationFrame(tick);
  };
  raf = requestAnimationFrame(tick);

  return () => {
    cancelAnimationFrame(raf);
    removeEventListener("keydown", onKey);
  };
}
