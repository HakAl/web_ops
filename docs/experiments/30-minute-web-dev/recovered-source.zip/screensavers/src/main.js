import { savers, byId } from "./savers/index.js";
import { setupEggs } from "./eggs.js";
import { setupMidi } from "./midi.js";

const app = document.getElementById("app");
const VISIBLE = 3;
let carouselIndex = 0;

// One canvas (and so one WebGL context) per screensaver for the whole visit.
// The same canvas is moved between carousel card, preview monitor and
// fullscreen overlay. Creating fresh contexts on every carousel click hits
// the browser's ~16 live-context limit, since lost contexts still count
// until they're garbage collected.
const pool = new Map(); // id -> { canvas, opts, error? }

function instance(saver) {
  let inst = pool.get(saver.id);
  if (!inst) {
    inst = { canvas: document.createElement("canvas"), opts: { speed: 1 } };
    try {
      saver.create(inst.canvas, inst.opts);
    } catch (err) {
      inst.error = err;
    }
    pool.set(saver.id, inst);
  }
  return inst;
}

// Puts the saver's canvas into `slot`, or an error message if WebGL failed.
function mount(saver, slot) {
  const inst = instance(saver);
  slot.replaceChildren(inst.error
    ? Object.assign(document.createElement("div"), {
      className: "gl-error",
      textContent: "ur browser cant do WebGL :( " + inst.error.message,
    })
    : inst.canvas);
  return inst;
}

// ---------- Home: carousel ----------

function renderHome() {
  app.innerHTML = `
    <h2 class="rainbow">~*~ Pick a ScreenSaver ~*~</h2>
    <div class="carousel">
      <button class="bevel nav" id="prev" title="previous">&lt;&lt;</button>
      <div class="track" id="track"></div>
      <button class="bevel nav" id="next" title="next">&gt;&gt;</button>
    </div>
    <p class="count">Showing ${savers.length} screensaver${savers.length === 1 ? "" : "z"} - more coming soon!!!</p>
  `;
  document.getElementById("prev").onclick = () => shift(-1);
  document.getElementById("next").onclick = () => shift(1);
  renderTrack();
}

function shift(d) {
  carouselIndex = (carouselIndex + d + savers.length) % savers.length;
  renderTrack();
}

// Left/Right arrows page the carousel, unless a game window has the keys.
addEventListener("keydown", (e) => {
  if (!document.getElementById("track") || document.querySelector(".game-win")) return;
  if (e.target.closest?.("input, select, textarea")) return;
  if (e.key === "ArrowLeft") shift(-1);
  if (e.key === "ArrowRight") shift(1);
});

function renderTrack() {
  const track = document.getElementById("track");
  track.innerHTML = "";
  const n = Math.min(VISIBLE, savers.length);
  for (let i = 0; i < n; i++) {
    const saver = savers[(carouselIndex + i) % savers.length];
    const card = document.createElement("a");
    card.className = "card";
    card.href = `#/s/${saver.id}`;
    card.innerHTML = `
      <div class="thumb-frame"></div>
      <div class="card-name">${saver.name}</div>
      <div class="card-blurb">${saver.blurb}</div>
      <div class="card-go blink">&gt;&gt; CLICK HERE &lt;&lt;</div>
    `;
    track.appendChild(card);
    mount(saver, card.querySelector(".thumb-frame"));
  }
}

// ---------- Detail: Win95-ish Display Properties ----------

function renderDetail(saver) {
  app.innerHTML = `
    <div class="win95">
      <div class="titlebar">
        <span>Display Properties - ${saver.name}</span>
        <a class="x bevel" href="#/" title="close">x</a>
      </div>
      <div class="win-body">
        <div class="tabs"><span>Background</span><span class="active">Screen Saver</span><span>Appearance</span><span>Settings</span></div>
        <div class="monitor">
          <div class="screen" id="screen"></div>
          <div class="monitor-neck"></div><div class="monitor-base"></div>
        </div>
        <fieldset>
          <legend>Screen Saver</legend>
          <div class="row">
            <select id="pick">${savers.map((s) => `<option value="${s.id}" ${s === saver ? "selected" : ""}>${s.name}</option>`).join("")}</select>
            <button class="bevel" id="fs">Preview</button>
          </div>
          <div class="row">
            <label for="speed">Speed:</label>
            <span>Slow</span><input type="range" id="speed" min="0.2" max="4" step="0.1" /><span>Fast</span>
          </div>
          <p class="desc">${saver.blurb}</p>
        </fieldset>
        <div class="row right"><a class="bevel btn" href="#/">OK</a><a class="bevel btn" href="#/">Cancel</a></div>
      </div>
    </div>
  `;
  const screen = document.getElementById("screen");
  const inst = mount(saver, screen);
  const speed = document.getElementById("speed");
  speed.value = inst.opts.speed;
  speed.oninput = (e) => (inst.opts.speed = +e.target.value);
  document.getElementById("pick").onchange = (e) => (location.hash = `#/s/${e.target.value}`);
  document.getElementById("fs").onclick = () => fullscreen(saver, screen);
}

// Real screensaver behaviour: any key or mouse move after a short grace period
// exits. The saver's canvas is borrowed from `home` and handed back on exit.
function fullscreen(saver, home) {
  const inst = instance(saver);
  if (inst.error) return;
  const overlay = document.createElement("div");
  overlay.className = "fs-overlay";
  overlay.appendChild(inst.canvas);
  document.body.appendChild(overlay);
  overlay.requestFullscreen?.().catch(() => {});

  const armedAt = performance.now() + 800;
  let done = false;
  // Escape is swallowed by the browser to leave fullscreen, so also exit on that.
  const onFsChange = () => {
    if (!document.fullscreenElement) close();
  };
  const exit = () => {
    if (performance.now() >= armedAt) close();
  };
  const close = () => {
    if (done) return;
    done = true;
    if (home.isConnected) home.appendChild(inst.canvas);
    overlay.remove();
    if (document.fullscreenElement) document.exitFullscreen();
    ["mousemove", "keydown", "mousedown"].forEach((e) => removeEventListener(e, exit));
    document.removeEventListener("fullscreenchange", onFsChange);
  };
  ["mousemove", "keydown", "mousedown"].forEach((e) => addEventListener(e, exit));
  document.addEventListener("fullscreenchange", onFsChange);
}

// ---------- Router ----------

function route() {
  const m = location.hash.match(/^#\/s\/([\w-]+)/);
  const saver = m && byId(m[1]);
  if (saver) renderDetail(saver);
  else renderHome();
}

addEventListener("hashchange", route);
route();
setupEggs();
setupMidi();

// Fake-but-persistent hit counter, as was tradition.
const hits = (+localStorage.getItem("hits") || 1337) + 1;
localStorage.setItem("hits", hits);
document.getElementById("counter").textContent = String(hits).padStart(7, "0");
