// Sprite batching for screensavers with "drawn" art. Cells are tiny (32px)
// and sampled NEAREST on purpose: chunky VGA-era pixels. Each painter draws one
// cell of a 2D-canvas atlas; the atlas becomes a WebGL texture and sprites are
// drawn as one batch of textured quads in world units (y down).
import { createProgram } from "./gl.js";

const VS = `
attribute vec2 aPos;
attribute vec2 aUV;
attribute float aAlpha;
uniform vec2 uWorld;
varying vec2 vUV;
varying float vAlpha;
void main() {
  vec2 p = aPos / uWorld * 2.0 - 1.0;
  gl_Position = vec4(p.x, -p.y, 0.0, 1.0);
  vUV = aUV;
  vAlpha = aAlpha;
}`;

const FS = `
precision mediump float;
uniform sampler2D uTex;
varying vec2 vUV;
varying float vAlpha;
void main() {
  vec4 c = texture2D(uTex, vUV);
  gl_FragColor = vec4(c.rgb, c.a * vAlpha);
}`;

const COLS = 4;
const FLOATS = 5; // x, y, u, v, alpha

export function createSpriteBatch(gl, painters, cell = 32) {
  const rows = Math.ceil(painters.length / COLS);
  const atlas = document.createElement("canvas");
  atlas.width = COLS * cell;
  atlas.height = rows * cell;
  const ctx = atlas.getContext("2d");
  painters.forEach((paint, i) => {
    ctx.save();
    ctx.translate((i % COLS) * cell, Math.floor(i / COLS) * cell);
    ctx.beginPath();
    ctx.rect(0, 0, cell, cell);
    ctx.clip();
    ctx.scale(cell / 128, cell / 128); // painters draw in a 128x128 space
    paint(ctx);
    ctx.restore();
  });

  const tex = gl.createTexture();
  gl.bindTexture(gl.TEXTURE_2D, tex);
  gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, atlas);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);

  // Half-texel inset so linear filtering doesn't bleed neighbouring cells.
  const uvs = painters.map((_, i) => {
    const x = (i % COLS) * cell, y = Math.floor(i / COLS) * cell;
    return [(x + 0.5) / atlas.width, (y + 0.5) / atlas.height,
      (x + cell - 0.5) / atlas.width, (y + cell - 0.5) / atlas.height];
  });

  const prog = createProgram(gl, VS, FS);
  const aPos = gl.getAttribLocation(prog, "aPos");
  const aUV = gl.getAttribLocation(prog, "aUV");
  const aAlpha = gl.getAttribLocation(prog, "aAlpha");
  const uWorld = gl.getUniformLocation(prog, "uWorld");
  const buf = gl.createBuffer();
  let data = new Float32Array(64 * 6 * FLOATS);

  // sprites: [{ i, x, y, w, h, flip?, alpha? }], x/y are the sprite centre.
  function draw(sprites, worldW, worldH) {
    const need = sprites.length * 6 * FLOATS;
    if (data.length < need) data = new Float32Array(need * 2);
    let o = 0;
    for (const s of sprites) {
      let [u0, v0, u1, v1] = uvs[s.i];
      if (s.flip) [u0, u1] = [u1, u0];
      const a = s.alpha ?? 1;
      const x0 = s.x - s.w / 2, x1 = s.x + s.w / 2;
      const y0 = s.y - s.h / 2, y1 = s.y + s.h / 2;
      const quad = [x0, y0, u0, v0, x1, y0, u1, v0, x0, y1, u0, v1,
        x0, y1, u0, v1, x1, y0, u1, v0, x1, y1, u1, v1];
      for (let k = 0; k < 24; k += 4) {
        data[o++] = quad[k];
        data[o++] = quad[k + 1];
        data[o++] = quad[k + 2];
        data[o++] = quad[k + 3];
        data[o++] = a;
      }
    }
    gl.enable(gl.BLEND);
    gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
    gl.useProgram(prog);
    gl.uniform2f(uWorld, worldW, worldH);
    gl.bindTexture(gl.TEXTURE_2D, tex);
    gl.bindBuffer(gl.ARRAY_BUFFER, buf);
    gl.bufferData(gl.ARRAY_BUFFER, data.subarray(0, o), gl.DYNAMIC_DRAW);
    const stride = FLOATS * 4;
    gl.enableVertexAttribArray(aPos);
    gl.vertexAttribPointer(aPos, 2, gl.FLOAT, false, stride, 0);
    gl.enableVertexAttribArray(aUV);
    gl.vertexAttribPointer(aUV, 2, gl.FLOAT, false, stride, 8);
    gl.enableVertexAttribArray(aAlpha);
    gl.vertexAttribPointer(aAlpha, 1, gl.FLOAT, false, stride, 16);
    gl.drawArrays(gl.TRIANGLES, 0, o / FLOATS);
  }

  return { draw };
}
